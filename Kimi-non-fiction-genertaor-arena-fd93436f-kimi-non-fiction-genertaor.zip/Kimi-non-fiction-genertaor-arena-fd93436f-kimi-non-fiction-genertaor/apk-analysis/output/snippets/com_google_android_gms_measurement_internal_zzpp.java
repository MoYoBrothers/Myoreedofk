package com.google.android.gms.measurement.internal;
public final class zzpp extends com.google.android.gms.measurement.internal.zzjf {
    public static final synthetic int zza;
    private static final String[] zzb;
    private static final String[] zzc;
    private java.security.SecureRandom zzd;
    private final java.util.concurrent.atomic.AtomicLong zze;
    private int zzf;
    private androidx.privacysandbox.ads.adservices.java.measurement.MeasurementManagerFutures zzg;
    private Boolean zzh;
    private Integer zzi;
}
