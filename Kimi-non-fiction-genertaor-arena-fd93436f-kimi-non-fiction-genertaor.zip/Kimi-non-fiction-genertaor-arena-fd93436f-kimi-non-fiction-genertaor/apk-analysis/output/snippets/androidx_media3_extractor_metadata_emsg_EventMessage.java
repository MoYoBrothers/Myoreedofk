package androidx.media3.extractor.metadata.emsg;
public final class EventMessage implements androidx.media3.common.Metadata$Entry {
    private static final androidx.media3.common.Format ID3_FORMAT = None;
    public static final String ID3_SCHEME_ID_AOM = "https://aomedia.org/emsg/ID3";
    private static final String ID3_SCHEME_ID_APPLE = "https://developer.apple.com/streaming/emsg-id3";
    private static final androidx.media3.common.Format SCTE35_FORMAT = None;
    public static final String SCTE35_SCHEME_ID = "urn:scte:scte35:2014:bin";
    public final long durationMs;
    private int hashCode;
    public final long id;
    public final byte[] messageData;
    public final String schemeIdUri;
    public final String value;
}
