#!/usr/bin/env python3
"""
extract_endpoints.py — Exhaustive URI/URL/endpoint harvester for Android APKs.

Static analysis only. v2: memory-lean engine (no global Analysis object, so it
scales to large multi-dex apps without OOM):

  1. AndroidManifest.xml      -> package identity, deep links, provider
                                 authorities, meta-data, cleartext config
  2. classes*.dex             -> full string table per dex + bytecode walk
                                 (const-string instructions) to attribute each
                                 URL/host/path to the class->method using it
  3. resources.arsc           -> all string resources (all configs)
  4. assets/ + res/raw/       -> raw text scan of bundled files
  5. lib/**/*.so              -> printable-run scan (catches Flutter Dart AOT
                                 snapshots where Flutter apps keep their APIs)

Output: endpoints.json + endpoints.csv + summary.json in <output_dir>.

Usage: python3 extract_endpoints.py <app.apk> <output_dir>
"""

import csv
import io
import json
import os
import re
import sys
import zipfile
from collections import defaultdict

try:
    from loguru import logger as _ag_logger
    _ag_logger.remove()
except Exception:
    pass
import logging
logging.getLogger().setLevel(logging.ERROR)

from androguard.core.axml import AXMLPrinter
from androguard.core.apk import ARSCParser
from androguard.core.dex import DEX

# ----------------------------------------------------------------------------
# Regexes
# ----------------------------------------------------------------------------

RE_URL = re.compile(r"(?:(?:https?|wss?|ws|ftp)://)[^\s\"'<>\\)\]}]+", re.I)
RE_URL_CLEAN = re.compile(r"[.,;:!)\]}'\"]+$")

_TLDS = (
    "com|net|org|edu|gov|mil|int|info|biz|io|ai|app|dev|co|me|tv|cc|us|uk|fr|de|eu|"
    "dz|ma|tn|ng|za|eg|sa|ae|qa|kw|bh|om|jo|lb|tr|in|pk|bd|id|my|sg|hk|cn|jp|kr|au|nz|"
    "ca|mx|br|ar|cl|org\.dz|net\.dz|edu\.dz|gov\.dz|"
    "cloud|digital|mobile|site|online|tech|store|space|xyz|top|link|works|life|"
    "services|solutions|company|directory|systems|tools|world|today|zone|live|"
    "one|now|new|pro|vip|icu|club|fun|games|press|media|news|network|hub|lab|labs"
)
RE_HOST = re.compile(
    r"(?<![\w.@-])((?:[a-zA-Z0-9](?:[a-zA-Z0-9_-]*[a-zA-Z0-9])?\.)+(" + _TLDS + r"))(?![\w.-])"
)

_FP_EXT = {
    "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "bmp", "tiff", "css", "less",
    "scss", "js", "mjs", "ts", "tsx", "jsx", "json", "xml", "html", "htm", "txt",
    "md", "yml", "yaml", "properties", "ini", "cfg", "conf", "csv", "tsv", "so",
    "dex", "apk", "jar", "zip", "gz", "tar", "rar", "7z", "pdf", "doc", "docx",
    "xls", "xlsx", "ppt", "ttf", "otf", "woff", "woff2", "eot", "mp3", "mp4",
    "avi", "mov", "mkv", "wav", "ogg", "flac", "db", "sqlite", "realm", "bin",
    "dat", "proto", "gradle", "kts", "lock", "log", "sh", "bat", "ps1", "py",
    "class", "kt", "java", "arsc", "res", "lua", "wasm",
}
_API_HINTS = re.compile(
    r"(?:^|[/\s])(?:api|apis|rest|graphql|gql|service|services|gateway|backend|"
    r"oauth|oauth2|auth|token|sso|saml|v\d+(?:\.\d+)?|mobile|public|private|"
    r"customer|customers|subscriber|subscribers|billing|payment|payments|pay|"
    r"recharge|topup|top-ups|bundle|bundles|package|packages|subscription|"
    r"subscriptions|offer|offers|catalog|catalogue|product|products|account|"
    r"accounts|user|users|profile|profiles|session|sessions|otp|verify|"
    r"notification|notifications|push|selfcare|self-care|invoice|"
    r"invoices|usage|consumption|balance|sim|msisdn|kyc|agent|dealer|"
    r"register|login|logout|refresh)(?:[/\s]|$)",
    re.I,
)
RE_PATH_CAND = re.compile(r"^/?[A-Za-z0-9_\-]+(?:/[A-Za-z0-9_\-.:{}*]+){1,12}/?$")

_JUNK = re.compile(
    r"^(?:android|java|com\.android|androidx|kotlin|kotlinx|org\.w3|"
    r"http://(?:schemas\.android|www\.w3|ns\.adobe|apache\.org)|"
    r"http://xml\.apache\.org)"
)
_JUNK_HOSTS = {
    "schemas.android.com", "www.w3.org", "w3.org", "ns.adobe.com", "xml.apache.org",
    "apache.org", "purl.org", "schemas.microsoft.com", "java.sun.com",
    "xml.org", "openxmlformats.org",
}


def clean_url(u: str) -> str:
    u = RE_URL_CLEAN.sub("", u)
    while u and u[-1] in "'\"":
        u = u[:-1]
    return u


def host_ok(h: str) -> bool:
    if h.lower() in _JUNK_HOSTS:
        return False
    parts = h.lower().rstrip(".").split(".")
    if len(parts) < 2:
        return False
    if parts[-1] in _FP_EXT:
        return False
    # '.cc' is overwhelmingly C++ source filenames inside native libs
    # (libflutter.so / libmlkit contain hundreds of "foo_bar.cc" strings)
    if parts[-1] == "cc":
        return False
    if all(p.isdigit() for p in parts):
        return False
    tld = parts[-1]
    return tld.isalpha() and 2 <= len(tld) <= 24


def path_ok(p: str) -> bool:
    if len(p) < 3 or len(p) > 200:
        return False
    if " " in p:
        return False
    if p.startswith("L") and p.endswith(";"):        # dex class descriptor
        return False
    if re.match(r"^L[a-z][a-z0-9_]*(?:/[A-Za-z0-9_$]+)+$", p):  # descriptor w/o ';'
        return False
    if re.match(r"^[a-z]+/[a-z0-9][a-z0-9.+-]*$", p, re.I):  # MIME type
        return False
    low = p.lower()
    if any(low.endswith("." + e) for e in _FP_EXT):
        return False
    if _JUNK.match(p):
        return False
    if not RE_PATH_CAND.match(p):
        return False
    if not _API_HINTS.search(p) and not re.search(r"/v\d+", low):
        return False
    return True


def interesting(s: str):
    """Yield ('url'|'host'|'api-path', value) for network-looking content."""
    for m in RE_URL.finditer(s):
        u = clean_url(m.group(0))
        if not _JUNK.match(u):
            yield ("url", u)
    if len(s) <= 300:
        for m in RE_HOST.finditer(s):
            h = m.group(1).lower().rstrip(".")
            if host_ok(h):
                yield ("host", h)
    if path_ok(s.strip()):
        yield ("api-path", s.strip()[:200])


# ----------------------------------------------------------------------------
# Findings store
# ----------------------------------------------------------------------------

class Store:
    def __init__(self):
        self.items = {}

    def add(self, key, kind, source, refs=None, extra=None):
        key = key.strip()
        if not key or _JUNK.match(key):
            return
        cur = self.items.get(key)
        if cur is None:
            self.items[key] = {
                "value": key, "kind": kind, "sources": {source},
                "refs": set(refs or []), "extra": dict(extra or {}),
            }
        else:
            cur["sources"].add(source)
            cur["refs"] |= set(refs or [])
            for k, v in (extra or {}).items():
                cur["extra"].setdefault(k, set()).add(v)

    def finalize(self):
        out = []
        for v in self.items.values():
            v["sources"] = sorted(v["sources"])
            v["refs"] = sorted(v["refs"])[:25]
            v["extra"] = {k: sorted(x for x in s if x)[:8] for k, s in v["extra"].items()}
            out.append(v)
        return out


# ----------------------------------------------------------------------------
# DEX pass (memory-lean)
# ----------------------------------------------------------------------------

def dex_pass(zf, store):
    """Per-dex: collect string table + map interesting strings to user code."""
    all_strings = set()
    refs = defaultdict(set)
    dex_names = sorted(n for n in zf.namelist()
                       if re.match(r"^classes\d*\.dex$", n))
    for dn in dex_names:
        data = zf.read(dn)
        d = DEX(data)
        try:
            strs = d.get_strings()
        except Exception as e:
            print("  [!] %s strings error: %s" % (dn, e), file=sys.stderr)
            strs = []
        all_strings.update(strs)
        n_cls = 0
        try:
            for cls in d.get_classes():
                n_cls += 1
                cn = cls.get_name()
                for m in cls.get_methods():
                    code = m.get_code()
                    if not code:
                        continue
                    ref = "%s->%s" % (cn, m.get_name())
                    try:
                        for insn in code.get_bc().get_instructions():
                            if "const-string" in insn.get_name():
                                try:
                                    sv = insn.get_string()
                                except Exception:
                                    continue
                                if isinstance(sv, str) and RE_URL.search(sv):
                                    refs[sv].add(ref)
                                    if len(refs[sv]) > 15:
                                        break
                    except Exception:
                        continue
        except Exception as e:
            print("  [!] %s classes error: %s" % (dn, e), file=sys.stderr)
        print("  [+] %s: %d strings, %d classes" % (dn, len(strs), n_cls))
        del d, data
    print("[+] %d unique string constants" % len(all_strings))

    for s in all_strings:
        srefs = refs.get(s)
        for kind, val in interesting(s):
            store.add(val, kind, "dex", refs=srefs)
        if srefs:
            # strings referenced by code but not matched above still matter
            if len(s) < 120 and not s.startswith("L") and " " not in s:
                rx = re.compile(r"^(?:/?[a-z][a-z0-9_\-]*(?:/[a-z0-9_\-.:{}*]+)+)/?$")
                mime_rx = re.compile(r"^[a-z]+/[a-z0-9][a-z0-9.+-]*$", re.I)
                if ("/" in s and not mime_rx.match(s) and rx.match(s)
                        and not s.lower().startswith(("lottie", "fonts/", "images/",
                                                      "img/", "anim/", "drawable",
                                                      "raw/", "assets/"))
                        and not any(s.lower().endswith("." + e) for e in _FP_EXT)):
                    store.add(s, "relative-path", "dex", refs=srefs)

    # credential-shaped strings
    for pat, label in (
        (r"^AIza[0-9A-Za-z_\-]{30,}$", "google-api-key"),
        (r"^sk_live_[0-9A-Za-z]+$", "stripe-secret(!)"),
        (r"^pk_(?:live|test)_[0-9A-Za-z]+$", "stripe-publishable"),
        (r"^eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.", "jwt-token"),
        (r"^AKIA[0-9A-Z]{16}$", "aws-access-key(!)"),
        (r"^xox[bpars]-[0-9A-Za-z\-]+$", "slack-token"),
        (r"^ghp_[0-9A-Za-z]+$", "github-token"),
    ):
        rx = re.compile(pat)
        for s in all_strings:
            if rx.match(s):
                store.add(s, "secret-style:" + label, "dex")
    return all_strings


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------

def main(apk_path, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    store = Store()

    print("[*] Parsing AndroidManifest.xml ...")
    with zipfile.ZipFile(apk_path) as z:
        manifest_xml = AXMLPrinter(z.read("AndroidManifest.xml")).get_xml() \
            .decode("utf-8", "replace")

    import xml.etree.ElementTree as ET
    NS = "{http://schemas.android.com/apk/res/android}"
    root = ET.fromstring(manifest_xml)

    a_meta = {}
    try:
        from pyaxmlparser import APK as PyAPK
        _pa = PyAPK(apk_path)
        pkg, ver, vercode = _pa.package, _pa.version_name, _pa.version_code
        app_name = _pa.application
    except Exception:
        pkg = root.get("package", "?")
        ver = root.get("{http://schemas.android.com/apk/res/android}versionName", "?")
        vercode = root.get("{http://schemas.android.com/apk/res/android}versionCode", "?")
        app_name = None
    print("[+] %s v%s (%s)" % (pkg, ver, vercode))
    store.add("PKG::%s" % pkg, "meta", "manifest", extra={
        "package": {pkg}, "version": {str(ver)}, "versionCode": {str(vercode)}})

    deep_links = []
    for activity in root.iter("activity"):
        aname = activity.get(NS + "name", "")
        for iff in activity.findall("intent-filter"):
            schemes, hosts, paths = set(), set(), set()
            for d in iff.findall("data"):
                s, h = d.get(NS + "scheme"), d.get(NS + "host")
                if s:
                    schemes.add(s)
                if h:
                    hosts.add(h)
                for attr in ("path", "pathPrefix", "pathPattern"):
                    pv = d.get(NS + attr)
                    if pv:
                        paths.add("%s=%s" % (attr, pv))
            has_view = any(
                (v.get(NS + "name", "").lower().endswith("action.view"))
                for v in iff.findall("action"))
            if schemes and has_view:
                for s in schemes:
                    for h in (hosts or {""}):
                        link = "%s://%s%s" % (s, h, ("/" + ",".join(sorted(paths))) if paths else "")
                        deep_links.append((link, aname))
                        store.add(link, "deeplink", "manifest", refs=[aname] if aname else [])

    authorities = set()
    for prov in root.iter("provider"):
        au = prov.get(NS + "authorities")
        if au:
            for part in au.split(";"):
                authorities.add(part)
                store.add("authority://" + part, "provider-authority", "manifest",
                          refs=[prov.get(NS + "name", "")])

    meta_strings = set()
    for m in root.iter("meta-data"):
        nm = m.get(NS + "name", "")
        mv = m.get(NS + "value", "")
        if nm:
            store.add("META::%s=%s" % (nm, mv[:120]), "manifest-meta", "manifest")
            if mv and not str(mv).startswith("@"):
                meta_strings.add((nm, mv))

    nsc_ref = None
    for m in root.iter("application"):
        nsc_ref = m.get(NS + "networkSecurityConfig")
        try:
            cleartext = m.get(NS + "usesCleartextTraffic")
        except Exception:
            cleartext = None
    store.add("SEC::usesCleartextTraffic=%s; networkSecurityConfig=%s" %
              (cleartext, nsc_ref), "security", "manifest")

    # ---- dex
    print("[*] DEX pass (strings + const-string xref walk) ...")
    with zipfile.ZipFile(apk_path) as z:
        all_strings = dex_pass(z, store)

    # ---- resources.arsc
    print("[*] resources.arsc string pool ...")
    try:
        with zipfile.ZipFile(apk_path) as z:
            arsc = ARSCParser(z.read("resources.arsc"))
        resolved = arsc.get_resolved_strings() or {}
        for _pkg, _cfgs in resolved.items():
            for _cfg, idmap in (_cfgs or {}).items():
                for _rid, val in (idmap or {}).items():
                    if isinstance(val, str) and val:
                        for kind, v in interesting(val):
                            store.add(v, kind, "resource")
    except Exception as e:
        print("  [!] arsc error: %s" % e, file=sys.stderr)

    # ---- bundled text files
    print("[*] Scanning bundled files (assets, res/raw, ...) ...")
    with zipfile.ZipFile(apk_path) as z:
        for info in z.infolist():
            name = info.filename
            if name.endswith("/"):
                continue
            low = name.lower()
            if info.file_size <= 6 * 1024 * 1024 and (
                    low.startswith(("assets/", "res/raw")) or
                    low.endswith((".json", ".xml", ".txt", ".properties",
                                  ".yml", ".yaml", ".cfg", ".conf", ".env",
                                  ".plist", ".html", ".js", ".graphql"))):
                try:
                    text = z.read(name).decode("utf-8", "replace")
                except Exception:
                    continue
                src = "file:" + name
                for kind, v in interesting(text):
                    store.add(v, kind, src)

    # ---- native libs (printable runs — Dart AOT snapshots keep URLs here)
    print("[*] Native library printable-run scan ...")
    RE_PRINTABLE = re.compile(rb"[\x20-\x7e]{4,}")
    with zipfile.ZipFile(apk_path) as z:
        for name in [n for n in z.namelist() if n.endswith(".so")]:
            try:
                data = z.read(name)
            except Exception:
                continue
            found = set()
            for raw in RE_PRINTABLE.findall(data):
                run = raw.decode("ascii", "ignore")
                for kind, v in interesting(run):
                    found.add((kind, v))
            for kind, v in found:
                if not _JUNK.match(v):
                    store.add(v, kind, "native:" + name)

    # ---- outputs
    print("[*] Writing outputs ...")
    findings = store.finalize()

    def kind_rank(k):
        return {"url": 0, "host": 1, "api-path": 2, "relative-path": 3,
                "deeplink": 4, "provider-authority": 5}.get(k, 9)

    findings.sort(key=lambda f: (kind_rank(f["kind"]), f["value"]))

    with open(os.path.join(out_dir, "endpoints.json"), "w") as f:
        json.dump({
            "app": {"package": pkg, "version": str(ver), "versionCode": str(vercode),
                    "name": app_name, "apk": os.path.basename(apk_path)},
            "manifest": {
                "deep_links": deep_links,
                "provider_authorities": sorted(authorities),
                "meta_data": sorted(set("%s = %s" % (n, v) for n, v in meta_strings)),
                "usesCleartextTraffic": str(cleartext),
                "networkSecurityConfig": str(nsc_ref),
            },
            "findings": findings,
        }, f, indent=2)

    with open(os.path.join(out_dir, "endpoints.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["kind", "value", "sources", "referenced_by"])
        for x in findings:
            w.writerow([x["kind"], x["value"], ";".join(x["sources"]),
                        " | ".join(x["refs"][:5])])

    by_kind = defaultdict(int)
    for x in findings:
        by_kind[x["kind"]] += 1
    summary = dict(by_kind)
    summary["dex_string_constants"] = len(all_strings)
    summary["deep_links"] = len(deep_links)
    print("[+] Done. Counts: %s" % json.dumps(summary, indent=2))
    with open(os.path.join(out_dir, "summary.json"), "w") as f:
        json.dump(summary, f, indent=2)


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1], sys.argv[2])
