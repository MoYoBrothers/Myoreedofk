package org.osmdroid.tileprovider.tilesource;
public class TileSourceFactory {
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase BASE_OVERLAY_NL;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase CLOUDMADESMALLTILES;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase CLOUDMADESTANDARDTILES;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase ChartbundleENRH;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase ChartbundleENRL;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase ChartbundleWAC;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase DEFAULT_TILE_SOURCE;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase FIETS_OVERLAY_NL;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase HIKEBIKEMAP;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase MAPNIK;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase OPEN_SEAMAP;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase OpenTopo;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase PUBLIC_TRANSPORT;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase ROADS_OVERLAY_NL;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase USGS_SAT;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase USGS_TOPO;
    public static final org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase WIKIMEDIA;
    private static java.util.List mTileSources;
}
