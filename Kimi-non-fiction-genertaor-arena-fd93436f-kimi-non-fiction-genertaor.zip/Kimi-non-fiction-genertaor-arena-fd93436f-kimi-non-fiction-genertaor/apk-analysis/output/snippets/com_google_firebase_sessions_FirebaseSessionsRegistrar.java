package com.google.firebase.sessions;
public final class FirebaseSessionsRegistrar implements com.google.firebase.components.ComponentRegistrar {
    private static final com.google.firebase.sessions.FirebaseSessionsRegistrar$Companion Companion = None;
    public static final String LIBRARY_NAME = "fire-sessions";
    private static final com.google.firebase.components.Qualified appContext;
    private static final com.google.firebase.components.Qualified backgroundDispatcher;
    private static final com.google.firebase.components.Qualified blockingDispatcher;
    private static final com.google.firebase.components.Qualified firebaseApp;
    private static final com.google.firebase.components.Qualified firebaseInstallationsApi;
    private static final com.google.firebase.components.Qualified firebaseSessionsComponent;
    private static final com.google.firebase.components.Qualified transportFactory;
}
