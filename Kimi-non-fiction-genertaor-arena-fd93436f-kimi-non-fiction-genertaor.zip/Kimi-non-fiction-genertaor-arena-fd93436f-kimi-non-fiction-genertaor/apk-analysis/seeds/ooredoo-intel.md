# Target app intel — My Ooredoo Algeria (`com.algeria.selfcare.app.android`)

Pre-analysis priors assembled from public sources (Morphe/ReVanced-style patch
sources for this exact package, app-store metadata). Used to cross-validate the
harvest from the actual APK.

## App identity
| Field | Value |
|---|---|
| Package | `com.algeria.selfcare.app.android` |
| Current version | 1.5.17 (uptodown, ~192 MB APK, SHA256 `a64b2281af700518232870124b5e187c19f6958b5bb8297e402154404e51861c`) |
| Cert (uptodown listing) | `86f98bfe693f4ab3fc0d93daa4a822bf` |
| Dev | Ooredoo Algérie (`ooredoo.dz`) |
| Framework | **Flutter** (`lib/<arch>/libapp.so`, `io.flutter.plugin.common.MethodCall`) |
| Flutter main activity | `com.example.ooredoo_selfcare_algeria.MainActivity` |

## Consequences for analysis
- Endpoints mostly live in the **Dart AOT snapshot** `lib/*/libapp.so`, not in
  `classes.dex`. The DEX layer is plugin glue (CleverTap, flutter plugins).
  → the native `.so` byte-string pass in `extract_endpoints.py` is the primary
  source for this target; DEX passes catch manifest/meta/plugin endpoints.

## Known security stack (from public patch code targeting this package)
| Concern | Classes / markers to expect |
|---|---|
| Analytics | `com.clevertap.android.sdk.Application` ("CleverTapAPI") |
| SSL pinning | Dart-side, patched in `libapp.so` itself |
| Root/emulator detection | `com.example.root_checker_plus.RootCheckerPlusPlugin`, `com.xamdesign.safe_device.*` (RootedCheck, EmulatorCheck, ExternalStorageCheck), `com.emrys.rjsniffer.rjsniffer.*`, `com.android.sec.utils.Rttx`, `com.example.ooredoo_selfcare_algeria.BinaryProtections` |
| Play Integrity | `com.android.sec.utils.Play`, `com.emrys.aic.app_integrity_checker.AppIntegrityCheckerPlugin` (`getChecksum`, `getSignature`) |
| Frida detection | maps scan ("DisableFridaMapsScanPatch" exists) |

## Payment integrations (from 2021 changelog)
- CIB card payment, EDAHABIA card payment (Algérie Poste) — expect related
  payment-gateway endpoints in the harvest.

## Validation checklist for the final report
- [ ] `ooredoo.dz` / `ooredooalg` hosts present
- [ ] CleverTap endpoints present (`clevertap.com` / `api.clevertap*`)
- [ ] Flutter (`libapp.so`, `libflutter.so`) confirmed in APK structure
- [ ] Google/Firebase endpoints present
- [ ] CIB / EDAHABIA / SATIM-related payment hosts identified
