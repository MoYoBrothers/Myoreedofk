package org.osmdroid.bonuspack.location;
public class PicasaPOIProvider {
    String mAccessToken;
}
