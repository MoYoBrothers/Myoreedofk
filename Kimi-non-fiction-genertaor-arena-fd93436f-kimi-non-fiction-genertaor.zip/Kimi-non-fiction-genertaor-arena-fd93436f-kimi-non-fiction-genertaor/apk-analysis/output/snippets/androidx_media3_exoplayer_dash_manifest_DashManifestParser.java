package androidx.media3.exoplayer.dash.manifest;
public class DashManifestParser extends org.xml.sax.helpers.DefaultHandler implements androidx.media3.exoplayer.upstream.ParsingLoadable$Parser {
    private static final java.util.regex.Pattern CEA_608_ACCESSIBILITY_PATTERN = None;
    private static final java.util.regex.Pattern CEA_708_ACCESSIBILITY_PATTERN = None;
    private static final int[] DOLBY_AC4_CHANNEL_CONFIGURATION_MAPPING = None;
    private static final java.util.regex.Pattern FRAME_RATE_PATTERN = None;
    private static final int[] MPEG_CHANNEL_CONFIGURATION_MAPPING = None;
    private static final String TAG = "MpdParser";
    private final org.xmlpull.v1.XmlPullParserFactory xmlParserFactory;
}
