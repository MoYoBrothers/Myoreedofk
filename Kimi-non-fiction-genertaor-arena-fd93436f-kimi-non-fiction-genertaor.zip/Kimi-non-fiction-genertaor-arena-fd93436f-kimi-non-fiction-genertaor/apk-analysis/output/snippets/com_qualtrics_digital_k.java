package com.qualtrics.digital;
 class k {
    java.util.Map a;
    final String b;
    final String c;
    final String d;
    final java.util.Map e;
    final String f;
    final com.qualtrics.digital.SDKUtils g;
    final boolean h;
    final com.qualtrics.digital.D i;
    private final com.qualtrics.digital.Properties j;
    com.qualtrics.digital.HeadlessStartResponse k;
    java.util.Map l;
}
