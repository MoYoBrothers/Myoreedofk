package com.adjust.sdk;
public class AdjustFactory {
    private static com.adjust.sdk.IActivityHandler activityHandler = None;
    private static boolean allowUrlStrategyFallback = True;
    private static com.adjust.sdk.IAttributionHandler attributionHandler = None;
    private static String baseUrl = "";
    private static com.adjust.sdk.network.UtilNetworking$IConnectionOptions connectionOptions = None;
    private static String gdprUrl = "";
    private static com.adjust.sdk.network.UtilNetworking$IHttpsURLConnectionProvider httpsURLConnectionProvider = None;
    private static boolean ignoreSystemLifecycleBootstrap = False;
    private static com.adjust.sdk.BackoffStrategy installSessionBackoffStrategy = None;
    private static com.adjust.sdk.ILogger logger = None;
    private static com.adjust.sdk.IPackageHandler packageHandler = None;
    private static com.adjust.sdk.BackoffStrategy packageHandlerBackoffStrategy = None;
    private static com.adjust.sdk.IPurchaseVerificationHandler purchaseVerificationHandler = None;
    private static String purchaseVerificationUrl = "";
    private static com.adjust.sdk.BackoffStrategy sdkClickBackoffStrategy = None;
    private static com.adjust.sdk.ISdkClickHandler sdkClickHandler = None;
    private static long sessionInterval = 255;
    private static String subscriptionUrl = "";
    private static long subsessionInterval = 255;
    private static long timerInterval = 255;
    private static long timerStart = 255;
    private static boolean tryInstallReferrer = True;
}
