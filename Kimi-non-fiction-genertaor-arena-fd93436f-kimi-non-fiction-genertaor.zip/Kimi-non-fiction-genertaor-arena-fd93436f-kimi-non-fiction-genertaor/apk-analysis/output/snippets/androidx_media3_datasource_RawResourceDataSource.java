package androidx.media3.datasource;
public final class RawResourceDataSource extends androidx.media3.datasource.BaseDataSource {
    public static final String RAW_RESOURCE_SCHEME = "rawresource";
    private final android.content.Context applicationContext;
    private android.content.res.AssetFileDescriptor assetFileDescriptor;
    private long bytesRemaining;
    private androidx.media3.datasource.DataSpec dataSpec;
    private java.io.InputStream inputStream;
    private boolean opened;
}
