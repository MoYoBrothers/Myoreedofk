package com.google.android.gms.auth.api.signin;
public class GoogleSignInOptions extends com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable implements com.google.android.gms.common.api.Api$ApiOptions$Optional, com.google.android.gms.common.internal.ReflectedParcelable {
    public static final android.os.Parcelable$Creator CREATOR;
    public static final com.google.android.gms.auth.api.signin.GoogleSignInOptions DEFAULT_GAMES_SIGN_IN;
    public static final com.google.android.gms.auth.api.signin.GoogleSignInOptions DEFAULT_SIGN_IN;
    public static final com.google.android.gms.common.api.Scope zaa;
    public static final com.google.android.gms.common.api.Scope zab;
    public static final com.google.android.gms.common.api.Scope zac;
    public static final com.google.android.gms.common.api.Scope zad;
    public static final com.google.android.gms.common.api.Scope zae;
    private static final java.util.Comparator zag;
    final int zaf;
    private final java.util.ArrayList zah;
    private android.accounts.Account zai;
    private boolean zaj;
    private final boolean zak;
    private final boolean zal;
    private String zam;
    private String zan;
    private java.util.ArrayList zao;
    private String zap;
    private java.util.Map zaq;
}
