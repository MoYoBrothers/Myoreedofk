package androidx.media3.exoplayer.drm;
public final class FrameworkMediaDrm implements androidx.media3.exoplayer.drm.ExoMediaDrm {
    private static final String CENC_SCHEME_MIME_TYPE = "cenc";
    public static final androidx.media3.exoplayer.drm.ExoMediaDrm$Provider DEFAULT_PROVIDER = None;
    private static final String MOCK_LA_URL = "<LA_URL>https://x</LA_URL>";
    private static final String MOCK_LA_URL_VALUE = "https://x";
    private static final String TAG = "FrameworkMediaDrm";
    private static final int UTF_16_BYTES_PER_CHARACTER = 2;
    private final android.media.MediaDrm mediaDrm;
    private int referenceCount;
    private final java.util.UUID uuid;
}
