# My Ooredoo Algeria (v1.5.17) — Static Reverse-Engineering Workspace

Course assignment: decompile the Android app **My Ooredoo Algeria**
(`com.algeria.selfcare.app.android`) and inventory **every URI / URL / API
endpoint** embedded in it, plus feature-level API flow reconstruction.

Everything lives under [`apk-analysis/`](apk-analysis/):

| Path | Contents |
|---|---|
| `apk-analysis/output/Ooredoo-1.5.17-findings-bundle.md` | **Start here** — complete findings bundle (all endpoints, deep links, hosts, config, security posture + Power-of-Snake / Spin-&-Win API deep-dives) |
| `apk-analysis/output/feature-power-of-snake.md` | **Power of Snake deep-dive** — full API reference (list + unlock/prize-delivery calls), purchase-response grant flag, module file map, state machine, gating keys, evidence & confidence table |
| `apk-analysis/output/endpoints.json` / `.csv` | Machine-readable inventory with `class -> method` references |
| `apk-analysis/output/report.md` | Raw full report |
| `apk-analysis/output/snippets/` | 30 decompiled Java classes |
| `apk-analysis/seeds/ooredoo-intel.md` | Pre-analysis intel & validation checklist |
| `apk-analysis/tools/` | Reusable pipeline: `extract_endpoints.py` (harvester), `build_report.py`, `build_bundle.py`, `run_analysis.sh` |

## Headline results

- **258 URLs · 189 hosts · 291 API paths · 12 deep links · 11 provider authorities**
  harvested from 259,471 dex strings + resources + assets + native libs.
- First-party backend: `apis.ooredoo.dz` / `api.ooredoo.dz` BFF, Keycloak realm
  `myooredoo` (OIDC), ~200 `/api/ooredoo-bff/*` endpoints grouped by feature.
- App is **Flutter** — the real API surface lives in the Dart AOT snapshot
  (`libapp.so`), not `classes.dex`; the toolchain harvests it via printable-run
  scanning.

## Reproduce

```bash
pip3 install -r apk-analysis/tools/requirements.txt
bash apk-analysis/tools/run_analysis.sh <app.apk> output
```

*Educational static analysis only — all findings are client-visible strings
that ship inside the APK. No live systems were contacted.*
