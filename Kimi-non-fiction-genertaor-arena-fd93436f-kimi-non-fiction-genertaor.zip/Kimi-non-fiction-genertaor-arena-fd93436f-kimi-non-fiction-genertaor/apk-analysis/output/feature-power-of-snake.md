# Feature Deep-Dive: "Power of Snake" (Power Snake)

**App:** My Ooredoo Algeria (`com.algeria.selfcare.app.android`) v1.5.17 (1461)
**Method:** static analysis of the Flutter Dart AOT snapshot
(`lib/arm64-v8a/libapp.so`, 22.7 MB), the dex layer, and bundled assets.
**Evidence tags:** ✔ = literal string extracted from the binary · ◐ = high-confidence
inference from generated-code symbols · ✱ = server behaviour inferred from client
code (not directly observable statically)

---

## 1. What the feature is — mapping the in-app FAQ to code

The French FAQ the user sees in the app:

> 1. Achetez un forfait My Ooredoo et un Power of Snake sera ajouté à votre compte.
> 2. Retrouvez-le dans l'onglet « Powers of Snake » et débloquez-le dans les 7 jours suivant l'achat.
> 3. Découvrez votre cadeau surprise : de 2 Go jusqu'à 1 To d'internet gratuit.
> 4. Profitez de votre bonus pendant 3 jours (chaque forfait acheté vous donne un nouveau Power of Snake !)

| FAQ claim | Implementation evidence in the binary |
|---|---|
| *"Achetez un forfait… un Power of Snake sera ajouté"* | Purchase calls (`POST /api/ooredoo-bff/bundle/bundlePurchase/v2` ✔, `cvm/bundlePurchase` ✔, `bundle/boost/bundle-purchase` ✔, `bundle/yooz/purchase` ✔ …); the purchase-response model carries field `powerSnakeReward` ✔; helpers `isPowerSnakeEligibleFromResponse` ✔ and `checkPowerSnakeEnabledForBundle` ✔ decide whether the UI advertises a snake for that purchase. The **grant itself happens server-side** ✱ — the app only reads the flag. |
| *"Retrouvez-le dans l'onglet « Powers of Snake »"* | Tab/screen classes `PowerSnakesTab` ✔, `PowerSnakeTab` ✔, `PowerSnakeScreen` ✔, route `/PowerSnakeScreen` ✔; list fetched with `GET /api/ooredoo-bff/gamification/power-snake?status=AVAILABLE` ✔ |
| *"débloquez-le dans les 7 jours"* | Item field `expiryDate` ✔ rendered per snake; warning copy key `power_snake_unlock_warning_message` ✔; expired items simply stop being returned with `status=AVAILABLE` ✱ |
| *"cadeau surprise : de 2 Go jusqu'à 1 To"* | Prize amount is **not** in the binary — no GB/To literals exist ✔(absence). The unlock response and/or game config carries it; the reveal UI plays `assets/lotties/reveal_gift.json` ✔ and routes to `GiftScreen` ✔ |
| *"Profitez de votre bonus pendant 3 jours"* | Reward validity is a server-side property of the granted bundle ✱ (visible later via `gamification/history` ✔ and the standard "my rewards" surfaces) |
| *"chaque forfait acheté vous donne un nouveau Power of Snake"* | One snake per eligible purchase ✱ — again the `powerSnakeReward` flag per purchase response ✔ |

> **Note on the FAQ text itself:** the French/English/Arabic *sentences* are **not
> shipped in the APK** — only i18n *keys* are compiled in (e.g.
> `unlock_power_snake_description` ✔). The shipped translation files
> (`assets/flutter_assets/assets/translations/*.json`) are near-stubs (3 strings
> total). Runtime copy — including this FAQ, titles, prize wording — is delivered
> remotely (Firebase Remote Config / CleverTap keys + BFF assets), which is how
> Ooredoo can change offers without an app update.

## 2. Where the feature lives in the binary

The whole module is recoverable from Dart symbol/string literals — a textbook
clean-architecture Flutter feature:

```
features/power_snake/
├── data/
│   ├── models/       power_snake_model.dart ✔   power_snake_reedem_model.dart ✔   faq_item_model.dart ✔
│   ├── repository/   power_snake_repo.dart ✔        (BasePowerSnakeRepo ✔ / PowerSnakeRepo ✔)
│   └── source/       power_snake_api.dart ✔         (BaseRemotePowerSnakeApi ✔ / RemotePowerSnakeApi ✔)
├── domain/
│   ├── entities/     power_snake.dart ✔   faq_item.dart ✔
│   ├── repository/   power_snake_repo.dart ✔
│   └── usecases/     get_power_snakes_usecase.dart ✔   unlock_power_snake_usecase.dart ✔
└── presentation/
    ├── logic/        power_snake_cubit.dart ✔ (+ freezed states)   power_snake_state.dart ✔
    └── screens/      power_snake_screen.dart ✔  power_snake_about_tab.dart ✔ (+ widgets: PowerSnakeCard ✔,
                      PowerSnakeBottomSheet ✔, PowerSnakeEpaymentBottomSheet ✔,
                      PowerSnakePurchaseSuccessCard ✔, PowerSnakeSuccessBottomSheet ✔)
```

A **Yooz sub-brand twin** exists (`package:yooz/ui/screens/gamification/power_snake/…` ✔,
`YzPowerSnakeSheet` ✔, `/YoozPuzzleSnakeWebView` ✔) — same feature re-skinned for
the Yooz prepaid brand.

## 3. API reference (reconstructed)

Base URL: `https://apis.ooredoo.dz` ✔ (first-party BFF; also appears as bare
`http://apis.ooredoo.dz` literal — see bundle §3).
**Headers on every call:** `Authorization: Bearer <Keycloak-OIDC-token>` ✔
(realm `myooredoo`, endpoints in bundle §2.3) and `X-Device-Fingerprint` ✔.

### 3.1 `GET /api/ooredoo-bff/gamification/power-snake?status=AVAILABLE`

*"Retrouvez-le dans l'onglet Powers of Snake"* — list my granted, not-yet-unlocked snakes.

```
Request   GET /api/ooredoo-bff/gamification/power-snake?status=AVAILABLE
          Authorization: Bearer eyJ…
Response  PowerSnakeModel ✔  =  {
            "total": <int>,                      ✔  'PowerSnakeModel(total: '
            "snakes": [                          ✔  ', snakes: '
              {                                  PowerSnakeItemModel ✔
                "uuid":        "<id>",          ✔  'PowerSnakeItemModel(uuid: '
                "status":      "AVAILABLE",     ✔  status enum: AVAILABLE ✔ / REDEEMED ✔ / EXPIRED (family) 
                "expiryDate":  "<ts>",          ✔  ', expiryDate: '
                "reward":      "…",             ✔  ', reward: '  /  ', assignedReward: '
                "redeemedDate": "<ts>"|null,    ✔  ', redeemedDate: '
                "bundleName":  "…"              ✔  ', bundleName: '
              }, …
            ]
          }
```
Symbol chain: `GetPowerSnakesUseCase` ✔ → `PowerSnakeRepo` ✔ → `RemotePowerSnakeApi` ✔.

### 3.2 `POST /api/ooredoo-bff/gamification/power-snake/{uuid}` ◐ — **the unlock / prize-delivery call**

The literal base path ends with `/` ✔ (`"/api/ooredoo-bff/gamification/power-snake/"`);
`UnlockPowerSnakeUseCase` ✔ → `unlockPowerSnake` ✔ appends the item's `uuid` ◐
(the per-call suffix isn't a standalone string literal, so the exact spelling of
the suffix — plain `{uuid}` vs `unlock/{uuid}` — can't be proven statically).

```
Request   POST /api/ooredoo-bff/gamification/power-snake/{uuid}
          Authorization: Bearer …
Response  PowerSnakeRedeemResponse ✔ = { "message": "…", … }   ✔  'PowerSnakeRedeemResponse(message: '
```

Client reaction chain (all ✔ literals): `powerSnakeUnlockLoading(snakes:)` →
`powerSnakeUnlockSuccess(message:)` → `showUnlockPowerSnakeBottomSheet` /
`PowerSnakeSuccessBottomSheet` → `reveal_gift.json` lottie → `GiftScreen`
(`naviagteToGiftScreen`, `prizesWon`, `lastPrizePartWon`).
Failure: `powerSnakeUnlockFailed(message:)`, log `"Failed to unlock power snake: "` ✔.
Trigger UI: `unlock_power_snake` / `unlock_my_power_snake` buttons ✔, `_unlock@…` ✔.
The *prize value itself* is decided and recorded server-side ✱ — the client only
displays what the backend returns (see §5).

### 3.3 Where the snake comes from — the purchase response

```
Request   POST /api/ooredoo-bff/bundle/bundlePurchase/v2        (family ✔: cvm/bundlePurchase,
          …                                                       bundle/boost/bundle-purchase,
                                                                … bundle/yooz/purchase, bundle/scholar/purchase, …)
Response  { …, "powerSnakeReward": true, "hasEPayment": …, … }   ✔ ', powerSnakeReward: '  ✔ ', hasEPayment' family
```
`isPowerSnakeEligibleFromResponse` ✔ gates the post-purchase card
(`PowerSnakePurchaseSuccessCard` ✔) — *"un Power of Snake sera ajouté à votre compte"*.
`PowerSnakeEpaymentBottomSheet` ✔ shows paid bundles (ePay/IPG) also grant snakes.

### 3.4 Framework endpoints shared with the gamification family

| Endpoint | Use |
|---|---|
| `GET  /api/ooredoo-bff/gamification/status` | enablement / attempts / eligibility flags |
| `POST /api/ooredoo-bff/gamification/play`   | generic play tracking (Spin & Win / Flarie siblings) |
| `GET  /api/ooredoo-bff/gamification/history` | prize history (`initGamificationHistoryTab` ✔) |

All ✔ literals.

## 4. Client state machine

freezed union `PowerSnakeState` ✔ (states are literal):

```
powerSnakeInitial()                       idle
powerSnakeLoading()                       listing snakes
powerSnakeSuccess(snakes:)                list rendered
powerSnakeFailed(message:)                list error
powerSnakeUnlockLoading(snakes:)          POST unlock in flight
powerSnakeUnlockSuccess(message:)         prize revealed (lottie + bottom sheet)
powerSnakeUnlockFailed(message:)          unlock rejected/expired
```
Driver: `PowerSnakeCubit` ✔. popup bookkeeping: `getPowerSnakePopupLastShown` /
`markPowerSnakeShown` ✔.

## 5. Server-authoritative vs client-side (what this means)

| Aspect | Authority |
|---|---|
| Whether a purchase grants a snake | **Server** ✱ — client reads `powerSnakeReward` from the purchase response |
| Listing & the 7-day expiry | **Server** ✱ — `status=AVAILABLE` filter, `expiryDate` field |
| The prize amount (2 GB … 1 TB) | **Server** ✱ — no prize-table literals in the binary ✔(absence) |
| Unlock acceptance / 3-day reward validity | **Server** ✱ — response `{message}`; grants land as real bundles |
| Rendering, animation, analytics | Client ✔ |

There is **no third-party prize URL** anywhere in the app — the entire prize
lifecycle runs on Ooredoo's own BFF ✔(absence + endpoint set).

## 6. Feature gating, security & ancillary literals

- **Remote-config keys** (Firebase Remote Config / CleverTap): `myo_puzzle_snake_enabled`,
  `is_puzzle_snake_auto_popup_enabled`, `myo_power_snake_auto_popup_restricted_time_in_hours`,
  `myo_puzzle_snake_auto_popup_restricted_time_in_hours`, `myo_power_snake_popup_image`,
  `myo_puzzle_snake_title`, `myo_puzzle_snake_url`, `excluded_rate_for_puzzle_snake`,
  `myo_is_disabled_employee_check_for_puzzle_snake`, `POWER_SNAKE`, `gamification-UI-Enable` — all ✔
- **Logic helpers:** `checkPowerSnakeTimeRestriction` ✔ (popup time windows),
  `checkPowerSnakeEnabledForBundle` ✔, `handlePuzzleSnakeDeeplink` ✔ (deep-link entry —
  routes `/PuzzleSnakeWebView` ✔; custom-scheme deep links in bundle §5)
- **Analytics events** (CleverTap/Firebase): `onPowerSnakeAccessed`, `onPowerSnakeActivation`,
  `onPowerSnakeAttribution`, `onPowerSnakePopupViewed` ✔
- **i18n keys (values delivered remotely):** `unlock_power_snake`, `unlock_my_power_snake`,
  `unlock_power_snake_description`, `unlock_power_snake_description2`,
  `unlock_power_snake_success_title`, `unlock_power_snake_success_description`,
  `power_snake_unlock_warning_message` ✔
- **Assets:** `assets/lotties/reveal_gift.json` ✔, `fab_gift.json`, `game_gift.json` ✔(family)
- **Error strings:** `"Failed to load power snakes: "`, `"Failed to unlock power snake: "`,
  `"Error in Puzzle Snake: "` ✔

## 7. Confidence & gaps

| Claim | Confidence |
|---|---|
| Endpoints `…power-snake?status=AVAILABLE` (GET, list) | Certain (literal) |
| Purchase-response field `powerSnakeReward` grants the snake | High (literal field + helper names) |
| Unlock = `POST …power-snake/{uuid}` | High — path base + use-case chain; exact suffix shape ◐ |
| Response models' field names | High (toString fragments are generated from field names; JSON key casing may differ) |
| Server-side grant/prize decisions | Inferred (client never contains prize data; unavoidable for static analysis) |

To close the ◐ gaps: dynamic analysis (MITM on a test device — requires defeating
Dart SSL pinning, cf. public Morphe patch) or a server-side spec.

## 8. Reproduce (fully offline/static)

```bash
pip3 install androguard
python3 - <<'EOF'
import zipfile, re
z = zipfile.ZipFile('ooredoo-merged.apk')   # base.apk + arm64 split merged
data = z.read('lib/arm64-v8a/libapp.so')
runs = re.findall(rb'[\x20-\x7e]{4,}', data)
for r in sorted({s.decode() for s in runs if 'nake' in s.decode()}):
    print(r)
EOF
```

---
*Part of the My Ooredoo v1.5.17 static-analysis workspace. Master inventory:
`Ooredoo-1.5.17-findings-bundle.md` (§1 = this feature). Sibling deep-dive:
Spin & Win (bundle §1.5).*
