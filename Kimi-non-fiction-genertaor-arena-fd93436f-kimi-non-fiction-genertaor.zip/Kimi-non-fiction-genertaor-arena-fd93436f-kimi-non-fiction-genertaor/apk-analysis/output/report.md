# API / Endpoint Inventory Report — static analysis

| | |
|---|---|
| App | **My Ooredoo** (`com.algeria.selfcare.app.android`) |
| Version | 1.5.17 (code 1461) |
| APK | `ooredoo-merged.apk` |
| Method | Static analysis (androguard DEX/ARSC/AXML parsing + full string-table harvest + cross-reference to code) |

**Legend:** *url* = absolute URL found in code/resources · *host* = bare hostname · *api-path* = endpoint path (Retrofit-style relative or path-looking constant) · *deeplink* = manifest URI scheme · *authority* = ContentProvider authority

## 1. First-party hosts & API surface

Hosts that do **not** belong to a known third-party SDK — i.e. the app's own backend surface:

| Host | Sources | Referenced by (code) |
|---|---|---|
| `a.tile.cloudmade.com` | dex | TileSourceFactory → <clinit> |
| `a.tile.opentopomap.org` | dex | TileSourceFactory → <clinit> |
| `a.tile.thunderforest.com` | dex | ThunderforestTileSource → <clinit> |
| `accounts.google.com` | dex | IdentityProviders → getIdentityProviderForAccount; zbb → run |
| `adjust.cn` | dex | — |
| `adjust.io` | dex | — |
| `adjust.net.in` | dex | — |
| `algeria.page.link` | native:lib/arm64-v8a/libapp.so | — |
| `aomedia.org` | dex | EventMessage → getWrappedMetadataFormat |
| `api.flickr.com` | dex | FlickrPOIProvider → getUrlInside |
| `api.flutter.dev` | native:lib/arm64-v8a/libapp.so | — |
| `api.geonames.org` | dex | GeoNamesPOIProvider → getUrlCloseTo; GeoNamesPOIProvider → getUrlInside |
| `api.ooredoo.dz` | native:lib/arm64-v8a/libapp.so | — |
| `apis.ooredoo.dz` | native:lib/arm64-v8a/libapp.so | — |
| `app.adjust.io` | dex | UrlStrategy → baseUrlChoices |
| `appassets.androidplatform.net` | dex | — |
| `archivefile.directory` | native:lib/arm64-v8a/libapp.so | — |
| `auth.cloudmade.com` | dex | CloudmadeUtil → getCloudmadeToken |
| `b.tile.cloudmade.com` | dex | TileSourceFactory → <clinit> |
| `b.tile.opentopomap.org` | dex | TileSourceFactory → <clinit> |
| `b.tile.thunderforest.com` | dex | ThunderforestTileSource → <clinit> |
| `basemap.nationalmap.gov` | dex | TileSourceFactory → <clinit> |
| `c.id` | dex | — |
| `c.tile.cloudmade.com` | dex | TileSourceFactory → <clinit> |
| `c.tile.opentopomap.org` | dex | TileSourceFactory → <clinit> |
| `c.tile.thunderforest.com` | dex | ThunderforestTileSource → <clinit> |
| `chartbundle.com` | dex | — |
| `clipstat.com` | dex | a → a; a → b; ApiUsageDataSyncer → a |
| `clock.system.now` | dex | — |
| `cloud.google.com` | dex | Validators → validateCryptoKeyUri |
| `cn.google.services` | dex | — |
| `cnvalias.icu` | native:lib/arm64-v8a/libflutter.so | — |
| `color.xyz` | native:lib/arm64-v8a/libflutter.so | — |
| `com.chrome.dev` | dex | — |
| `com.google.android.play.games` | dex | — |
| `com.google.android.tv` | dex | — |
| `com.google.android.wearable.app` | dex | — |
| `com.google.app.id` | dex | — |
| `com.qualtrics.digital` | dex | — |
| `com.repodroid.app` | dex, native:lib/arm64-v8a/libvdomain.so | — |
| `comob.org` | dex | Friends → callStartSharing; Friends → callStopSharing; Friends → callUpdateSharing |
| `console.firebase.google.com` | dex | ConsoleUrlGenerator → getRootUrl |
| `dart.io` | native:lib/arm64-v8a/libapp.so | — |
| `dartbug.com` | native:lib/arm64-v8a/libflutter.so | — |
| `dashif.org` | dex | DashMediaPeriod → findTrickPlayProperty; DashManifestParser → parseLastSegmentNumberSupplementalProperty; DashManifestParser → parseRoleFlagsFromProperties |
| `datetime.now` | native:lib/arm64-v8a/libapp.so | — |
| `debug.firebase.analytics.app` | dex | — |
| `dev.vdocipher.com` | dex | f → a; OptionsDownloader → b |
| `dev.virtualearth.net` | dex | BingMapTileSource → getMetaData |
| `developer.android.com` | dex, native:lib/arm64-v8a/libmlkit_google_ocr_pipeline.so | HttpDataSource$CleartextNotPermittedException → <init>; ExoPlayerImpl → verifyApplicationThread; ForceStopRunnable → run |
| `developer.apple.com` | dex | EventMessage → getWrappedMetadataFormat |
| `developer.mozilla.org` | native:lib/arm64-v8a/libapp.so | — |
| `dexterous.com` | dex, native:lib/arm64-v8a/libapp.so | — |
| `docs.flutter.dev` | dex, native:lib/arm64-v8a/libapp.so, native:lib/arm64-v8a/libflutter.so | FlutterLoader$1 → call |
| `dolby.com` | dex | — |
| `dts.com` | dex | — |
| `firebase.google.com` | dex, native:lib/arm64-v8a/libapp.so | zzgi → zzf; CrashlyticsCore → isBuildIdValid; CrashlyticsCore → onPreExecute |
| `firebase.installation.id` | dex | — |
| `flutter.baseflow.com` | dex, native:lib/arm64-v8a/libapp.so | — |
| `flutter.dev` | native:lib/arm64-v8a/libapp.so | — |
| `flutter.io` | native:lib/arm64-v8a/libapp.so | — |
| `frag_color.xyz` | native:lib/arm64-v8a/libflutter.so | — |
| `frag_info.color.xyz` | native:lib/arm64-v8a/libflutter.so | — |
| `frag_info.decal_border_color.xyz` | native:lib/arm64-v8a/libflutter.so | — |
| `g.co` | dex | RawResourceDataSource → openAssetFileDescriptor |
| `gcm.n.link` | dex | — |
| `gdpr.adjust.io` | dex | UrlStrategy → gdprUrlChoices |
| `github.com` | dex, native:lib/arm64-v8a/libapp.so, native:lib/arm64-v8a/libflutter.so, resource | MediaSessionLegacyStub$Api31 → setMediaButtonBroadcastReceiver; ActivityHandler → lambda$trackEvent$3$com-adjust-sdk-ActivityHandler; PermissionManager → onRequestPermissionsResult |
| `go.link` | dex | — |
| `google-analytics.com` | dex | — |
| `google.c.sender.id` | dex | — |
| `google.com` | dex | zzkx → run |
| `graphhopper.com` | dex | GeocoderGraphHopper → <init>; GraphHopperRoadManager → <init> |
| `image.network` | native:lib/arm64-v8a/libapp.so | — |
| `intent.extra.update.info` | dex | — |
| `interners.new` | dex | — |
| `issuetracker.google.com` | dex | ViewDataBinding → checkAndCastToBindingComponent; DataStoreImpl$data$1$invokeSuspend$$inlined$map$1$2 → emit; DataStoreImpl$data$1 → invokeSuspend |
| `journeyapps.com` | resource | — |
| `link.id` | dex | — |
| `link.media` | dex | — |
| `llvm.googlesource.com` | native:lib/arm64-v8a/libflutter.so | — |
| `login.live.com` | dex | — |
| `login.yahoo.com` | dex | — |
| `maps.wikimedia.org` | dex | TileSourceFactory → <clinit> |
| `measurement.remove_conflicting_first_party_apis.dev` | dex | — |
| `measurement.sgtm.client.upload_on_backgrounded.dev` | dex | — |
| `media.glamour.com` | native:lib/arm64-v8a/libapp.so | — |
| `meta.vdocipher.com` | dex | CastVdoPlayer → b; f → a; VdoPreCacheManager → a |
| `my-ooredoo-new-app.appspot.com` | native:lib/arm64-v8a/libapp.so | — |
| `my-ooredoo-new-app.firebasestorage.app` | native:lib/arm64-v8a/libapp.so, resource | — |
| `my-ooredoo.go.link` | native:lib/arm64-v8a/libapp.so | — |
| `n.lb` | native:lib/arm64-v8a/libopenssl.so | — |
| `non-r.id` | dex | — |
| `ooredoo.dz` | native:lib/arm64-v8a/libapp.so | — |
| `oouc14.prod.google.com` | native:lib/arm64-v8a/libmlkit_google_ocr_pipeline.so | — |
| `open.mapquestapi.com` | dex | MapQuestRoadManager → getUrl |
| `openptmap.org` | dex | TileSourceFactory → <clinit> |
| `orker.id` | dex | — |
| `overpass-api.de` | dex | OverpassAPIProvider → <init> |
| `pagead2.googlesyndication.com` | dex | zza → run |
| `picasaweb.google.com` | dex | PicasaPOIProvider → getUrlInside |
| `play.google.com` | dex, native:lib/arm64-v8a/libapp.so | LaunchexternalappPlugin → openApp; MessengerUtils → openMessengerInPlayStore; QualtricsPopOverActivity → onCreate |
| `plugins.flutter.dev` | dex | — |
| `plugins.flutter.io` | dex, native:lib/arm64-v8a/libapp.so | — |
| `plugins.it_nomads.com` | dex, native:lib/arm64-v8a/libapp.so | — |
| `plus.me` | dex | — |
| `predicates.in` | dex | — |
| `pub.dev` | native:lib/arm64-v8a/libapp.so | — |
| `response.id` | dex | — |
| `ro.build.display.id` | native:lib/arm64-v8a/libflutter.so | — |
| `ro.build.id` | native:lib/arm64-v8a/libmlkit_google_ocr_pipeline.so | — |
| `s.qualtrics.com` | dex | k → d |
| `s.xyz` | native:lib/arm64-v8a/libflutter.so | — |
| `schemas.google.com` | dex | PicasaXMLHandler → startElement |
| `script.id` | dex | — |
| `siteintercept.qualtrics.com` | dex | — |
| `sk_fragcoord_workaround.xyz` | native:lib/arm64-v8a/libflutter.so | — |
| `solusibejo.com` | dex, native:lib/arm64-v8a/libapp.so | — |
| `ssrv.adjust.io` | dex | UrlStrategy → purchaseVerificationUrlChoices |
| `subscription.adjust.io` | dex | UrlStrategy → subscriptionUrlChoices |
| `survey.qualtrics.com` | dex | w → a |
| `svgpicture.network` | native:lib/arm64-v8a/libapp.so | — |
| `systemuioverlay.top` | dex | — |
| `tiles.openseamap.org` | dex | TileSourceFactory → <clinit> |
| `tiles.wmflabs.org` | dex | TileSourceFactory → <clinit> |
| `time.android.com` | dex | — |
| `tz.id` | dex | — |
| `tzdatetime.now` | native:lib/arm64-v8a/libapp.so | — |
| `u.id` | native:lib/arm64-v8a/libopenssl.so | — |
| `uemoji.icu` | native:lib/arm64-v8a/libflutter.so, native:lib/arm64-v8a/libmlkit_google_ocr_pipeline.so | — |
| `ulayout.icu` | native:lib/arm64-v8a/libflutter.so, native:lib/arm64-v8a/libmlkit_google_ocr_pipeline.so | — |
| `v_color.xyz` | native:lib/arm64-v8a/libflutter.so | — |
| `vnd.ahead.space` | native:lib/arm64-v8a/libapp.so | — |
| `vnd.dece.mobile` | native:lib/arm64-v8a/libapp.so | — |
| `window.top` | dex | — |
| `wms.chartbundle.com` | dex | TileSourceFactory → <clinit> |
| `workspec.id` | dex | — |
| `www.example.com` | dex | BrowserActionsIntent → getBrowserActionsIntentHandlers; BrowserActionsIntent → launchIntent; CustomTabsHelper → getPackageNameToUse |
| `www.flickr.com` | dex | FlickrPOIProvider → getThem |
| `www.google.com` | dex, native:lib/arm64-v8a/libapp.so | KmlDocument → saveAsKML |
| `www.ibm.com` | native:lib/arm64-v8a/libapp.so | — |
| `www.leptonica.com` | native:lib/arm64-v8a/libmlkit_google_ocr_pipeline.so | — |
| `www.opengis.net` | dex | KmlDocument → saveAsKML |
| `www.tensorflow.org` | native:lib/arm64-v8a/libmlkit_google_ocr_pipeline.so | — |
| `www.unicode.org` | native:lib/arm64-v8a/libflutter.so | — |
| `www.vdocipher.com` | dex | e → b |
| `youtrack.jetbrains.com` | dex | PropertyReference → getReflected |

### API endpoint paths (relative paths / route constants)

| Path | Referenced by (class → method) |
|---|---|
| `/A/V0h1` | — |
| `/api/auth/realms/myooredoo/protocol/openid-connect/logout` | — |
| `/api/auth/realms/myooredoo/protocol/openid-connect/token` | — |
| `/api/auth/realms/myooredoo/protocol/openid-connect/userinfo` | — |
| `/api/meta/` | — |
| `/api/meta/o/` | — |
| `/api/ooredoo-bff/5G/register` | — |
| `/api/ooredoo-bff/anaflix/getContent` | — |
| `/api/ooredoo-bff/anaflix/getUser` | — |
| `/api/ooredoo-bff/anaflix/play` | — |
| `/api/ooredoo-bff/anaflix/purchase` | — |
| `/api/ooredoo-bff/anazik/content/getContent` | — |
| `/api/ooredoo-bff/anazik/content/getUser` | — |
| `/api/ooredoo-bff/anazik/player/stream` | — |
| `/api/ooredoo-bff/anazik/service/getSubPlans` | — |
| `/api/ooredoo-bff/anazik/service/subscribe` | — |
| `/api/ooredoo-bff/anazik/service/unsubscribe` | — |
| `/api/ooredoo-bff/asset/file` | — |
| `/api/ooredoo-bff/attestation/challenge` | — |
| `/api/ooredoo-bff/available-services/change` | — |
| `/api/ooredoo-bff/biometric/token` | — |
| `/api/ooredoo-bff/bundle/boost/bundle-purchase` | — |
| `/api/ooredoo-bff/bundle/boost/eligible-bundles` | — |
| `/api/ooredoo-bff/bundle/bundleConversion` | — |
| `/api/ooredoo-bff/bundle/bundlePurchase/v2` | — |
| `/api/ooredoo-bff/bundle/bundleRefill` | — |
| `/api/ooredoo-bff/bundle/free-calls/activate` | — |
| `/api/ooredoo-bff/bundle/getActivePackages` | — |
| `/api/ooredoo-bff/bundle/getBundleConvertEligibility` | — |
| `/api/ooredoo-bff/bundle/others/bundle-purchase` | — |
| `/api/ooredoo-bff/bundle/others/eligible-bundles` | — |
| `/api/ooredoo-bff/bundle/purchase/byop` | — |
| `/api/ooredoo-bff/bundle/scholar/purchase` | — |
| `/api/ooredoo-bff/bundle/slave/bundlePurchase` | — |
| `/api/ooredoo-bff/bundle/social-bundle/purchase` | — |
| `/api/ooredoo-bff/bundle/tod/purchase` | — |
| `/api/ooredoo-bff/bundle/yooz/byop` | — |
| `/api/ooredoo-bff/bundle/yooz/purchase` | — |
| `/api/ooredoo-bff/bundle/yooz/super/purchase` | — |
| `/api/ooredoo-bff/checkpoint/token` | — |
| `/api/ooredoo-bff/credit/advancedpayment` | — |
| `/api/ooredoo-bff/credit/p2p/confirm` | — |
| `/api/ooredoo-bff/credit/p2p/initiate` | — |
| `/api/ooredoo-bff/custom/token` | — |
| `/api/ooredoo-bff/cvm/boosters-bundles` | — |
| `/api/ooredoo-bff/cvm/bundlePurchase` | — |
| `/api/ooredoo-bff/cvm/cvm_optINOUT` | — |
| `/api/ooredoo-bff/cvm/dynamic-bundle-purchase` | — |
| `/api/ooredoo-bff/cvm/fusion-bearings` | — |
| `/api/ooredoo-bff/cvm/getBundles` | — |
| `/api/ooredoo-bff/cvm/getCvmAllocations` | — |
| `/api/ooredoo-bff/cvm/getPcBundles` | — |
| `/api/ooredoo-bff/cvm/scholar-bundles` | — |
| `/api/ooredoo-bff/cvm/status` | — |
| `/api/ooredoo-bff/cvm/yooz/get-bundles/v2` | — |
| `/api/ooredoo-bff/dashboard/database/sync` | — |
| `/api/ooredoo-bff/e-ticket` | — |
| `/api/ooredoo-bff/e-ticket/eligible` | — |
| `/api/ooredoo-bff/e-ticket/get-failed-tickets` | — |
| `/api/ooredoo-bff/favorite-numbers` | — |
| `/api/ooredoo-bff/favorite-numbers/` | — |
| `/api/ooredoo-bff/fayda/carousels` | — |
| `/api/ooredoo-bff/fayda/categories` | — |
| `/api/ooredoo-bff/fayda/partners/` | — |
| `/api/ooredoo-bff/fayda/use-offer/` | — |
| `/api/ooredoo-bff/flarie/player/token` | — |
| `/api/ooredoo-bff/fusion/eligibility` | — |
| `/api/ooredoo-bff/gamification/history` | — |
| `/api/ooredoo-bff/gamification/play` | — |
| `/api/ooredoo-bff/gamification/power-snake/` | — |
| `/api/ooredoo-bff/gamification/status` | — |
| `/api/ooredoo-bff/history` | — |
| `/api/ooredoo-bff/ipg/init` | — |
| `/api/ooredoo-bff/islamiyat/adhkar` | — |
| `/api/ooredoo-bff/islamiyat/advice-of-the-day` | — |
| `/api/ooredoo-bff/islamiyat/douaa-of-the-day` | — |
| `/api/ooredoo-bff/islamiyat/favorites` | — |
| `/api/ooredoo-bff/islamiyat/get-app-details` | — |
| `/api/ooredoo-bff/islamiyat/hadith-of-the-day` | — |
| `/api/ooredoo-bff/islamiyat/hijri-date` | — |
| `/api/ooredoo-bff/islamiyat/play-surat` | — |
| `/api/ooredoo-bff/islamiyat/preview-reciter` | — |
| `/api/ooredoo-bff/islamiyat/prophet-of-the-day` | — |
| `/api/ooredoo-bff/islamiyat/reciters` | — |
| `/api/ooredoo-bff/islamiyat/set-favourite` | — |
| `/api/ooredoo-bff/islamiyat/surat-of-the-day` | — |
| `/api/ooredoo-bff/islamiyat/surats` | — |
| `/api/ooredoo-bff/migration/change-bearing` | — |
| `/api/ooredoo-bff/migration/eligible-offers` | — |
| `/api/ooredoo-bff/migration/energy` | — |
| `/api/ooredoo-bff/migration/otp/request` | — |
| `/api/ooredoo-bff/migration/v2/changeContractOffer` | — |
| `/api/ooredoo-bff/migration/v2/status` | — |
| `/api/ooredoo-bff/nonEligible/getUser` | — |
| `/api/ooredoo-bff/nonEligible/prayertimes` | — |
| `/api/ooredoo-bff/nonEligible/v2/anaflix/getContent` | — |
| `/api/ooredoo-bff/nonEligible/weather/getWeatherCondition` | — |
| `/api/ooredoo-bff/noudjoum/balance` | — |
| `/api/ooredoo-bff/noudjoum/catalog` | — |
| `/api/ooredoo-bff/noudjoum/enroll` | — |
| `/api/ooredoo-bff/noudjoum/get_allocations` | — |
| `/api/ooredoo-bff/noudjoum/redeem` | — |
| `/api/ooredoo-bff/plan/data-share-pro/shared-data` | — |
| `/api/ooredoo-bff/plan/data-sharing/action` | — |
| `/api/ooredoo-bff/plan/laGold/activateMode` | — |
| `/api/ooredoo-bff/plan/laSwitch/disableDataSharing` | — |
| `/api/ooredoo-bff/plan/laSwitch/enableDataSharing` | — |
| `/api/ooredoo-bff/plan/laSwitch/limitDataSharing` | — |
| `/api/ooredoo-bff/plan/laSwitch/sharedData` | — |
| `/api/ooredoo-bff/plan/pntpp/sharedData` | — |
| `/api/ooredoo-bff/prayertimes/` | — |
| `/api/ooredoo-bff/prayertimes/v2` | — |
| `/api/ooredoo-bff/public/anaflix/getContent` | — |
| `/api/ooredoo-bff/public/anaflix/play` | — |
| `/api/ooredoo-bff/public/prayertimes` | — |
| `/api/ooredoo-bff/public/weather/getWeatherCondition` | — |
| `/api/ooredoo-bff/quiz/optout` | — |
| `/api/ooredoo-bff/quiz/profile` | — |
| `/api/ooredoo-bff/quiz/profile/game` | — |
| `/api/ooredoo-bff/quiz/profile/reply` | — |
| `/api/ooredoo-bff/quiz/profile/update` | — |
| `/api/ooredoo-bff/quiz/singleclicklogin` | — |
| `/api/ooredoo-bff/raffle-draw/eligibility` | — |
| `/api/ooredoo-bff/raffle-draw/register` | — |
| `/api/ooredoo-bff/ramadan/activate` | — |
| `/api/ooredoo-bff/ramadan/getAccountInfo` | — |
| `/api/ooredoo-bff/ramadan/getPlanAllocation` | — |
| `/api/ooredoo-bff/ramadan/purchases` | — |
| `/api/ooredoo-bff/ramadan/validity` | — |
| `/api/ooredoo-bff/renewal/getAutoRenewalStatus` | — |
| `/api/ooredoo-bff/rise/data/transfer` | — |
| `/api/ooredoo-bff/rise/delete-msisdn` | — |
| `/api/ooredoo-bff/rise/favourites` | — |
| `/api/ooredoo-bff/rise/transfer-history` | — |
| `/api/ooredoo-bff/rise/transfer-quota-values` | — |
| `/api/ooredoo-bff/sa/all` | — |
| `/api/ooredoo-bff/sa/master` | — |
| `/api/ooredoo-bff/sa/master/link-accounts` | — |
| `/api/ooredoo-bff/sa/master/unlink` | — |
| `/api/ooredoo-bff/sa/migration/status` | — |
| `/api/ooredoo-bff/sa/migration/v2/changeContractOffer` | — |
| `/api/ooredoo-bff/sa/requestOTP` | — |
| `/api/ooredoo-bff/sa/slave` | — |
| `/api/ooredoo-bff/sa/slave/logout` | — |
| `/api/ooredoo-bff/sa/slave/token` | — |
| `/api/ooredoo-bff/sa/slave/token/refresh` | — |
| `/api/ooredoo-bff/sahlabox/auth/login` | — |
| `/api/ooredoo-bff/sahlabox/auth/pretoken` | — |
| `/api/ooredoo-bff/sahlabox/auth/register` | — |
| `/api/ooredoo-bff/sahlabox/auth/reset/request` | — |
| `/api/ooredoo-bff/sahlabox/auth/token` | — |
| `/api/ooredoo-bff/scholar/eligibility` | — |
| `/api/ooredoo-bff/snap-chat/apply` | — |
| `/api/ooredoo-bff/snap-chat/eligibility` | — |
| `/api/ooredoo-bff/soccer/activate` | — |
| `/api/ooredoo-bff/soccer/eligibility-check` | — |
| `/api/ooredoo-bff/social/login` | — |
| `/api/ooredoo-bff/social/register` | — |
| `/api/ooredoo-bff/social/resendotp` | — |
| `/api/ooredoo-bff/sport/wc2026/checkElgibility` | — |
| `/api/ooredoo-bff/sport/wc2026/getClubsByCompetition` | — |
| `/api/ooredoo-bff/sport/wc2026/getFavoriteClubs` | — |
| `/api/ooredoo-bff/sport/wc2026/serviceActivation` | — |
| `/api/ooredoo-bff/subscriptions/getAccountInfo` | — |
| `/api/ooredoo-bff/transfer/data` | — |
| `/api/ooredoo-bff/user-info/willaya` | — |
| `/api/ooredoo-bff/userInfo` | — |
| `/api/ooredoo-bff/userInfo/getContract` | — |
| `/api/ooredoo-bff/userInfo/getCustomerTickets` | — |
| `/api/ooredoo-bff/userInfo/personal` | — |
| `/api/ooredoo-bff/userInfo/rise` | — |
| `/api/ooredoo-bff/users/activate` | — |
| `/api/ooredoo-bff/users/authping` | — |
| `/api/ooredoo-bff/users/autologin` | — |
| `/api/ooredoo-bff/users/changeEmail` | — |
| `/api/ooredoo-bff/users/changePassword` | — |
| `/api/ooredoo-bff/users/create-password` | — |
| `/api/ooredoo-bff/users/data-share-pro/get-slaves` | — |
| `/api/ooredoo-bff/users/deleteUser` | — |
| `/api/ooredoo-bff/users/detect` | — |
| `/api/ooredoo-bff/users/haya/recharge-mode` | — |
| `/api/ooredoo-bff/users/haya/switch-mode` | — |
| `/api/ooredoo-bff/users/loan/apply` | — |
| `/api/ooredoo-bff/users/loan/eligibleBands` | — |
| `/api/ooredoo-bff/users/mgm/attribute/update` | — |
| `/api/ooredoo-bff/users/mgm/info/apply` | — |
| `/api/ooredoo-bff/users/mgm/invitations` | — |
| `/api/ooredoo-bff/users/mgm/redeem` | — |
| `/api/ooredoo-bff/users/mgm/referral` | — |
| `/api/ooredoo-bff/users/quickaccess/register` | — |
| `/api/ooredoo-bff/users/recharge/pin` | — |
| `/api/ooredoo-bff/users/register` | — |
| `/api/ooredoo-bff/users/reset/password` | — |
| `/api/ooredoo-bff/users/reset/request` | — |
| `/api/ooredoo-bff/users/sendEmailverification` | — |
| `/api/ooredoo-bff/users/status` | — |
| `/api/ooredoo-bff/users/validateUser` | — |
| `/api/ooredoo-bff/weather/getWeatherCondition` | — |
| `/api/ooredoo-bff/yooz/reservation/msisdn/pickup` | — |
| `/api/ooredoo-bff/yooz/reservation/msisdn/prefix` | — |
| `/api/ooredoo-bff/yooz/reservation/msisdn/validate` | — |
| `/api/ooredoo-bff/yooz/reservation/pickup/details` | — |
| `/api/ooredoo-bff/yooz/reservation/token` | — |
| `/cms/api/haya-recharge-modes` | — |
| `/cms/api/migration-promoted-offers` | — |
| `/cms/api/product-offerings` | — |
| `/cms/api/startup-zones` | — |
| `/cms/v2/api/app-updates` | — |
| `/cms/v2/api/communes` | — |
| `/cms/v2/api/countries` | — |
| `/cms/v2/api/faqs` | — |
| `/cms/v2/api/product-offerings6` | — |
| `/cms/v2/api/soccer-clubsN` | — |
| `/cms/v2/api/startup-zones` | — |
| `/cms/v2/api/stores` | — |
| `/cms/v2/api/stores/nearby` | — |
| `/cms/v2/api/ui-labels` | — |
| `/cms/v2/api/wilayas` | — |
| `/data/misc/profiles/cur/0` | — |
| `/data/misc/profiles/cur/0/` | — |
| `/data/misc/profiles/ref/` | — |
| `/e-payment/payment/app/download` | — |
| `/privacy_sandbox/mobile/register/trigger` | — |
| `/usr/local/ssl/private` | — |
| `/v2/purchase` | — |
| `META-INF/services/` | — |
| `V9/5` | — |
| `api/ooredoo-bff/sa/slave/token/refresh` | — |
| `assets/images/non_svg/services/borntobedz.png4` | — |
| `crypto/ocsp/v3_ocsp.c` | — |
| `crypto/x509v3/v3_addr.c` | — |
| `crypto/x509v3/v3_akey.c` | — |
| `crypto/x509v3/v3_alt.c` | — |
| `crypto/x509v3/v3_asid.c` | — |
| `crypto/x509v3/v3_bcons.c` | — |
| `crypto/x509v3/v3_bitst.c` | — |
| `crypto/x509v3/v3_conf.c` | — |
| `crypto/x509v3/v3_cpols.c` | — |
| `crypto/x509v3/v3_crld.c` | — |
| `crypto/x509v3/v3_enum.c` | — |
| `crypto/x509v3/v3_extku.c` | — |
| `crypto/x509v3/v3_ia5.c` | — |
| `crypto/x509v3/v3_info.c` | — |
| `crypto/x509v3/v3_lib.c` | — |
| `crypto/x509v3/v3_ncons.c` | — |
| `crypto/x509v3/v3_pci.c` | — |
| `crypto/x509v3/v3_pcons.c` | — |
| `crypto/x509v3/v3_pmaps.c` | — |
| `crypto/x509v3/v3_prn.c` | — |
| `crypto/x509v3/v3_purp.c` | — |
| `crypto/x509v3/v3_skey.c` | — |
| `crypto/x509v3/v3_sxnet.c` | — |
| `crypto/x509v3/v3_tlsf.c` | — |
| `crypto/x509v3/v3_utl.c` | — |
| `oauth/access_token` | — |
| `research/ocr/api/internal/generate_word_entities.cc` | — |
| `research/ocr/api/internal/goodoc_util.cc` | — |
| `research/ocr/api/internal/layout_analyzer/associate_semantic_entities_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/cluster_lines_gcn_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/cluster_lines_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/cluster_sort_gcn_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/compute_font_info_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/compute_lang_id_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/confidence_filter_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/convert_curved_boxes_to_angled_boxes_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/create_region_blocks_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/estimate_image_structure_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/estimate_lines_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/estimate_paragraphs_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/estimate_word_colors.cc` | — |
| `research/ocr/api/internal/layout_analyzer/estimate_word_colors_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/fill_symbol_gaps_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/fill_symbol_gaps_step_utils.cc` | — |
| `research/ocr/api/internal/layout_analyzer/merge_lines_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/merge_split_detections_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/page_layout_analyzer.cc` | — |
| `research/ocr/api/internal/layout_analyzer/regenerate_words_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/remove_multiple_orientations_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/remove_overlapping_with_curved_boxes_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/remove_overlaps_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/remove_overlaps_word_pruning_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/resize_symbol_boxes_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/sort_entities_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/split_lines_gcn_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/split_lines_step.cc` | — |
| `research/ocr/api/internal/layout_analyzer/step_utils.cc` | — |
| `research/ocr/api/internal/page_layout_overlapping_remover.cc` | — |
| `research/ocr/api/internal/word_builder.cc` | — |
| `routed-bike/route/v1/driving/` | — |
| `routed-car/route/v1/driving/` | — |
| `routed-foot/route/v1/driving/` | — |

### Other relative paths that look like routes (needs manual triage)

```
```

## 2. Absolute URLs found

| URL | Kind evidence (referencing class → method) |
|---|---|
| `http://a.tile.cloudmade.com/%s/%d/%d/%d/%d/%d%s?token=%s` | TileSourceFactory → <clinit> |
| `http://api.geonames.org/findNearbyWikipediaJSON?` | GeoNamesPOIProvider → getUrlCloseTo |
| `http://api.geonames.org/wikipediaBoundingBoxJSON?` | GeoNamesPOIProvider → getUrlInside |
| `http://api.ooredoo.dz/Shops/getWilayas` | — |
| `http://api.tiles.mapbox.com/v4/` | MapQuestTileSource → <clinit> |
| `http://apis.ooredoo.dz` | — |
| `http://b.tile.cloudmade.com/%s/%d/%d/%d/%d/%d%s?token=%s` | TileSourceFactory → <clinit> |
| `http://b/24559754` | — |
| `http://c.tile.cloudmade.com/%s/%d/%d/%d/%d/%d%s?token=%s` | TileSourceFactory → <clinit> |
| `http://cpki-caweb.huawei.com/cpki/servlet/crlFileDown.crl?certype=1&/rootcrl.crl0` | — |
| `http://crl.securetrust.com/STCA.crl0` | — |
| `http://dashif.org/guidelines/last-segment-number` | DashManifestParser → parseLastSegmentNumberSupplementalProperty |
| `http://dashif.org/guidelines/thumbnail_tile` | DashManifestParser → parseTileCountFromProperties |
| `http://dashif.org/guidelines/trickmode` | DashMediaPeriod → findTrickPlayProperty; DashManifestParser → parseRoleFlagsFromProperties |
| `http://dashif.org/thumbnail_tile` | DashManifestParser → parseTileCountFromProperties |
| `http://fontello.com i c o n l y _ b o l d R e g u l a r i c o n l y _ b o l d i c o n l y _ b o l d V e r s i o n` | — |
| `http://g.co/dev/packagevisibility` | RawResourceDataSource → openAssetFileDescriptor |
| `http://javax.xml.XMLConstants/feature/secure-processing` | DOMDeserializer → <clinit>; DOMSerializer → <init> |
| `http://javax.xml.XMLConstants/property/accessExternalDTD` | DOMSerializer → <init> |
| `http://javax.xml.XMLConstants/property/accessExternalStylesheet` | DOMSerializer → <init> |
| `http://localhost` | FileBasedTileSource → getSource |
| `http://localhost/` | Response → error; Response → success |
| `http://logo.verisign.com/vslogo.gif0` | — |
| `http://maps.googleapis.com/maps/api/directions/xml?` | — |
| `http://maps.googleapis.com/maps/api/directions/xml?origin=` | GoogleRoadManager → getUrl |
| `http://openptmap.org/tiles/` | TileSourceFactory → <clinit> |
| `http://picasaweb.google.com/data/feed/api/all?` | PicasaPOIProvider → getUrlInside |
| `http://play.google.com/store/apps/details?id=com.facebook.orca` | MessengerUtils → openMessengerInPlayStore |
| `http://purl.org/dc/elements/1.1/` | — |
| `http://schemas.google.com/photos/2007#canonical` | PicasaXMLHandler → startElement |
| `http://schemas.microsoft.com/DRM/2007/03/protocols/AcquireLicense` | HttpMediaDrmCallback → executeKeyRequest |
| `http://www.apache.org/licenses/` | — |
| `http://www.apache.org/licenses/LICENSE-2.0` | — |
| `http://www.example.com` | CustomTabsHelper → getPackageNameToUse |
| `http://www.google.com/kml/ext/2.2` | KmlDocument → saveAsKML |
| `http://www.iandevlin.com/blog/2012/04/html5/cookies-json-localstorage-and-opera` | — |
| `http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd` | — |
| `http://www.opengis.net/kml/2.2` | KmlDocument → saveAsKML |
| `http://www.unicode.org/copyright.html` | — |
| `http://xml.org/sax/features/namespace-prefixes` | PicasaPOIProvider → getThem |
| `http://xml.org/sax/features/namespaces` | PicasaPOIProvider → getThem |
| `https://%s` | — |
| `https://%s-%s.%s` | D → a |
| `https://%s/%s/%s` | FirebaseInstallationServiceClient → getFullyQualifiedRequestUri |
| `https://.facebook.com` | Utility → clearFacebookCookies |
| `https://1.{domain` | HEREWeGoTileSource → <clinit> |
| `https://2.{domain` | HEREWeGoTileSource → <clinit> |
| `https://3.{domain` | HEREWeGoTileSource → <clinit> |
| `https://4.{domain` | HEREWeGoTileSource → <clinit> |
| `https://a.tile.opentopomap.org/` | TileSourceFactory → <clinit> |
| `https://a.tile.thunderforest.com/{map` | ThunderforestTileSource → <clinit> |
| `https://accounts.google.com` | IdentityProviders → getIdentityProviderForAccount |
| `https://accounts.google.com/o/oauth2/revoke?token=` | zbb → run |
| `https://algeria.page.link/mgm?referralCode=` | — |
| `https://algeria.page.link/referralCode?linkmgm=` | — |
| `https://algeria.page.link?link=` | — |
| `https://android.googlesource.com/toolchain/llvm-project` | — |
| `https://aomedia.org/emsg/ID3` | EventMessage → getWrappedMetadataFormat |
| `https://api.flickr.com/services/rest/?method=flickr.photos.search` | FlickrPOIProvider → getUrlInside |
| `https://api.flutter.dev/flutter/dart-ui/ChannelBuffers-class.html` | — |
| `https://api.flutter.dev/flutter/material/Scaffold/of.html` | — |
| `https://api.mapbox.com/v4/` | MapBoxTileSource → <clinit> |
| `https://api.openstreetmap.fr/oapi/interpreter` | — |
| `https://apis.ooredoo.dz` | — |
| `https://app` | UrlStrategy → baseUrlChoices |
| `https://app-measurement.com/a` | zzagu → zzaw; zzfy → <clinit> |
| `https://app-measurement.com/s/d` | zzagu → zzp; zzfy → <clinit> |
| `https://app.%s` | — |
| `https://app.adjust.com` | AdjustFactory → teardown; UrlStrategy → baseUrlChoices |
| `https://app.adjust.io` | UrlStrategy → baseUrlChoices |
| `https://auth.cloudmade.com/token/` | CloudmadeUtil → getCloudmadeToken |
| `https://b.tile.opentopomap.org/` | TileSourceFactory → <clinit> |
| `https://b.tile.thunderforest.com/{map` | ThunderforestTileSource → <clinit> |
| `https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryTopo/MapServer/tile/` | TileSourceFactory → <clinit> |
| `https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/tile/` | TileSourceFactory → <clinit> |
| `https://c.tile.opentopomap.org/` | TileSourceFactory → <clinit> |
| `https://c.tile.thunderforest.com/{map` | ThunderforestTileSource → <clinit> |
| `https://cdn.jsdelivr.net/npm/leaflet-hotline@0.4.0/dist/leaflet.hotline.min.js` | — |
| `https://cdn.jsdelivr.net/npm/leaflet-rotatedmarker@0.2.0/leaflet.rotatedMarker.min.js` | — |
| `https://cdnjs.cloudflare.com/ajax/libs/leaflet-plugins/3.4.0/layer/Marker.Rotate.min.js` | — |
| `https://cdnjs.cloudflare.com/ajax/libs/mapbox-polyline/1.1.1/polyline.min.js` | — |
| `https://clipstat.com/api/crash/log` | CrashLogSyncer → a |
| `https://clipstat.com/api/usage/log/` | ApiUsageDataSyncer → a |
| `https://clipstat.com/api/v2/` | a → a |
| `https://clipstat.com/api/v2/update/` | a → b |
| `https://cloud.google.com/kms/docs/reference/rest/v1/projects.locations.keyRings.cryptoKeys#CryptoKey` | Validators → validateCryptoKeyUri |
| `https://comob.org/sharing/` | — |
| `https://comob.org/sharing/jstart.php?nickname=` | Friends → callStartSharing |
| `https://comob.org/sharing/jstop.php?user_id=` | Friends → callStopSharing |
| `https://comob.org/sharing/jupdate.php?user_id=` | Friends → callUpdateSharing |
| `https://console.firebase.google.com` | ConsoleUrlGenerator → getRootUrl |
| `https://d1z78r8i505acl.cloudfront.net/a/?p=hls&o=` | u → e |
| `https://d2r1yp2w7bby2u.cloudfront.net/js/permission_grant.gif` | — |
| `https://d2r1yp2w7bby2u.cloudfront.net/js/wzrk_dialog.min.js` | — |
| `https://dartbug.com/52121` | — |
| `https://default.url` | FrameworkMediaDrm → adjustLicenseServerUrl |
| `https://dev.vdocipher.com` | f → a; OptionsDownloader → b |
| `https://dev.virtualearth.net/REST/V1/Imagery/Metadata/%s?mapVersion=v1&output=json&uriScheme=https&key=%s` | BingMapTileSource → getMetaData |
| `https://developer.android.com/build/agp-upgrade-assistant` | FirebaseSessionsRegistrar → <clinit> |
| `https://developer.android.com/google/play/integrity/reference/com/google/android/play/core/integrity/model/IntegrityErrorCode.html#` | a → a |
| `https://developer.android.com/google/play/integrity/reference/com/google/android/play/core/integrity/model/StandardIntegrityErrorCode.html#` | b → a |
| `https://developer.android.com/guide/topics/media/issues/cleartext-not-permitted` | HttpDataSource$CleartextNotPermittedException → <init> |
| `https://developer.android.com/guide/topics/media/issues/player-accessed-on-wrong-thread` | ExoPlayerImpl → verifyApplicationThread |
| `https://developer.android.com/guide/topics/permissions/overview` | PlatformPlugin → getClipboardData |
| `https://developer.android.com/kotlin/add-kotlin` | FirebaseSessionsRegistrar → <clinit> |
| `https://developer.android.com/reference/android/content/Context.html#getFilesDir` | — |
| `https://developer.android.com/reference/android/view/View#announceForAccessibility(java.lang.CharSequence` | AccessibilityBridge$1 → announce |
| `https://developer.android.com/reference/com/google/android/play/core/review/model/ReviewErrorCode.html#` | zza → zza |
| `https://developer.android.com/training/articles/direct-boot` | ForceStopRunnable → run |
| `https://developer.apple.com/streaming/emsg-id3` | EventMessage → getWrappedMetadataFormat |
| `https://developer.mozilla.org/en-US/docs/Web/API/WakeLockSentinel/released` | — |
| `https://developer.mozilla.org/en-US/docs/Web/HTTP/Status` | — |
| `https://developers.facebook.com/docs/android/getting-started` | Validate → hasFacebookActivity |
| `https://developers.facebook.com/docs/android/getting-started#add-app_id` | FacebookSdk → getClientToken |
| `https://developers.facebook.com/docs/android/getting-started#client-token` | GraphRequest → addCommonParameters |
| `https://developers.facebook.com/docs/android/getting-started/#client-access-token` | Validate → hasClientToken |
| `https://developers.facebook.com/docs/android/troubleshooting/#faq_267321845055988` | NativeProtocol$KatanaAppInfo → onAvailableVersionsNullOrEmpty |
| `https://developers.facebook.com/docs/app-events/getting-started-app-events-android#disable-auto-events` | UserSettingsManager → logWarnings |
| `https://developers.facebook.com/docs/sharing/android` | Validate → hasContentProvider |
| `https://docs.flutter.dev/deployment/android#what-are-the-supported-target-architectures` | FlutterLoader$1 → call |
| `https://docs.flutter.dev/release/breaking-changes/android-surface-plugins` | — |
| `https://docs.flutter.dev/release/breaking-changes/network-policy-ios-android` | — |
| `https://facebook.com` | Utility → clearFacebookCookies |
| `https://facebook.com/device?user_code=%1$s&qr=1` | DeviceAuthDialog$RequestState → setUserCode |
| `https://fb.gg/me/community/` | GamingGroupIntegration → showImpl |
| `https://fb.gg/me/friendfinder/` | FriendFinderDialog → showImpl |
| `https://fb.gg/me/media_asset/` | OpenGamingMediaDialog → onCompleted |
| `https://firebase-settings.crashlytics.com/spi/v2/platforms/android/gmp/%s/settings` | SettingsController → create |
| `https://firebase.google.com/docs/crashlytics/get-started?platform=android#add-plugin` | CrashlyticsCore → isBuildIdValid; CrashlyticsCore → onPreExecute |
| `https://firebase.google.com/docs/flutter/setup` | — |
| `https://firebase.google.com/support/` | RemoteConfigManager → lambda$triggerFirebaseRemoteConfigFetchAndActivateOnSuccessfulFetch$1$com-google-firebase-perf-config-RemoteConfigManager |
| `https://firebase.google.com/support/guides/disable-analytics` | zzgi → zzf |
| `https://firebase.google.com/support/privacy/init-options` | FirebaseInstallations → preConditionChecks |
| `https://firebaseremoteconfig.googleapis.com/v1/projects/%s/namespaces/%s:fetch` | ConfigFetchHttpClient → getFetchUrl |
| `https://firebaseremoteconfigrealtime.googleapis.com/v1/projects/%s/namespaces/%s:streamFetchInvalidations` | ConfigRealtimeHttpClient → getRealtimeURL |
| `https://fonts.gstatic.com/s/montserrat/v7/zhcz-_WihjSQC0oHJ9TCYL3hpw3pgy2gAi-Ip7WPMi0.woff` | — |
| `https://fonts.gstatic.com/s/opensans/v13/O4NhV7_qs9r9seTo7fnsVLO3LdcAZYWl9Si6vvxL-qU.woff` | — |
| `https://fonts.gstatic.com/s/opensans/v13/wMws1cEtxWZc6AZZIpiqWALUuEpTyoUstqEm5AMlJo4.woff` | — |
| `https://gdpr` | UrlStrategy → gdprUrlChoices |
| `https://gdpr.%s` | — |
| `https://gdpr.adjust.com` | AdjustFactory → teardown; UrlStrategy → gdprUrlChoices |
| `https://gdpr.adjust.io` | UrlStrategy → gdprUrlChoices |
| `https://github.com/Baseflow/flutter-permission-handler/issues` | PermissionManager → onRequestPermissionsResult |
| `https://github.com/adjust/android_sdk#can-i-trigger-an-event-at-application-launch` | ActivityHandler → lambda$trackEvent$3$com-adjust-sdk-ActivityHandler |
| `https://github.com/androidx/media/issues/1730` | MediaSessionLegacyStub$Api31 → setMediaButtonBroadcastReceiver |
| `https://github.com/dart-lang/language/issues/3488` | — |
| `https://github.com/dart-lang/sdk/blob/master/runtime/docs/compiler/aot/entry_point_pragma.md` | — |
| `https://github.com/flutter/flutter/issues` | — |
| `https://github.com/flutter/flutter/issues/165510` | AccessibilityBridge$1 → announce |
| `https://github.com/flutter/flutter/issues/65895` | — |
| `https://github.com/flutter/flutter/issues/new?template=02_bug.yml` | — |
| `https://github.com/journeyapps/zxing-android-embedded` | — |
| `https://github.com/richtr/NoSleep.js/issues/15` | — |
| `https://goo.gl/NAOOOI` | zzpp → zzC |
| `https://google.com/search?` | zzkx → run |
| `https://graph-video.%s` | ServerProtocol → getGraphVideoUrlBase |
| `https://graph.%s` | ServerProtocol → getFacebookGraphUrlBase; ServerProtocol → getGraphUrlBase; ServerProtocol → getGraphUrlBaseForSubdomain |
| `https://graphhopper.com/api/1/geocode?` | GeocoderGraphHopper → <init> |
| `https://graphhopper.com/api/1/route?` | GraphHopperRoadManager → <init> |
| `https://grs.dbankcloud.asia` | — |
| `https://grs.dbankcloud.cn` | — |
| `https://grs.dbankcloud.com` | — |
| `https://grs.dbankcloud.eu` | — |
| `https://grs.platform.dbankcloud.ru` | — |
| `https://issuetracker.google.com/328687152` | FirebaseSessionsRegistrar → <clinit> |
| `https://issuetracker.google.com/issues/116541301` | ViewDataBinding → checkAndCastToBindingComponent |
| `https://issuetracker.google.com/issues/241760537` | UpdatingDataContextElement → <clinit> |
| `https://issuetracker.google.com/issues/328687152#comment3` | FirebaseSessionsRegistrar → <clinit> |
| `https://issuetracker.google.com/issues/new?component=413107&template=1096568` | AutoCloser → autoCloser$lambda$3 |
| `https://issuetracker.google.com/issues/new?component=907884&template=1466542` | DataStoreImpl$data$1$invokeSuspend$$inlined$map$1$2 → emit; DataStoreImpl$data$1 → invokeSuspend; DataStoreImpl → readDataAndUpdateCache |
| `https://journeyapps.com/` | — |
| `https://llvm.googlesource.com/a/llvm-project` | — |
| `https://login.live.com` | — |
| `https://login.yahoo.com` | — |
| `https://maps.wikimedia.org/osm-intl/` | TileSourceFactory → <clinit> |
| `https://media.glamour.com/photos/63e04aa638cf710097af61fe/1:1/w_354%2Cc_limit/1246830852` | — |
| `https://meta.vdocipher.com` | f → a |
| `https://meta.vdocipher.com/api/meta/` | CastVdoPlayer → b |
| `https://meta.vdocipher.com/api/meta/o/` | VdoPreCacheManager → a |
| `https://metrics-dra.dt.hicloud.com:6447` | — |
| `https://metrics1.data.hicloud.com:6447` | — |
| `https://metrics2.data.hicloud.com:6447` | — |
| `https://metrics5.data.hicloud.com:6447` | — |
| `https://metrics5.dt.dbankcloud.ru:6447` | — |
| `https://nominatim.openstreetmap.org/` | ApiProvider → <clinit>; GeocoderNominatim → <init>; NominatimPOIProvider → <init> |
| `https://open.mapquestapi.com/guidance/v2/route?` | MapQuestRoadManager → getUrl |
| `https://open.mapquestapi.com/nominatim/v1/` | — |
| `https://overlay.openstreetmap.nl/basemap/` | TileSourceFactory → <clinit> |
| `https://overlay.openstreetmap.nl/openfietskaart-overlay/` | TileSourceFactory → <clinit> |
| `https://overlay.openstreetmap.nl/roads/` | TileSourceFactory → <clinit> |
| `https://overpass-api.de/api/interpreter` | OverpassAPIProvider → <init> |
| `https://pagead2.googlesyndication.com/pagead/gen_204?id=gmob-apps` | zza → run |
| `https://play.google.com/store/apps/details?id=` | LaunchexternalappPlugin → openApp; QualtricsPopOverActivity → onCreate |
| `https://play.google.com/store/apps/details?id=com.chouf.ondemandvideo` | — |
| `https://play.google.com/store/apps/details?id=com.lf.bs.hayamusic` | — |
| `https://pub.dev/` | — |
| `https://raw.githubusercontent.com/tangrams/bubble-wrap/gh-pages/images/building-grid.gif` | — |
| `https://raw.githubusercontent.com/tangrams/bubble-wrap/gh-pages/themes/images/bubble-wrap%402x.png` | — |
| `https://raw.githubusercontent.com/tangrams/bubble-wrap/gh-pages/themes/images/bubble-wrap-shields-international@2x.png` | — |
| `https://raw.githubusercontent.com/tangrams/bubble-wrap/gh-pages/themes/images/bubble-wrap-shields-usa@2x.png` | — |
| `https://routing.openstreetmap.de/` | OSRMRoadManager → <init> |
| `https://s.qualtrics.com/spoke/all/jam/unauthenticated-headless-api/v1/forms/%s/sessions/` | k → d |
| `https://s.qualtrics.com/spoke/all/jam/unauthenticated-headless-api/v1/forms/%s/sessions/?Q_SurveyVersionID=` | k → d |
| `https://ssrv` | UrlStrategy → purchaseVerificationUrlChoices |
| `https://ssrv.%s` | — |
| `https://ssrv.adjust.com` | AdjustFactory → teardown; UrlStrategy → purchaseVerificationUrlChoices |
| `https://ssrv.adjust.io` | UrlStrategy → purchaseVerificationUrlChoices |
| `https://subscription` | UrlStrategy → subscriptionUrlChoices |
| `https://subscription.%s` | — |
| `https://subscription.adjust.com` | AdjustFactory → teardown; UrlStrategy → subscriptionUrlChoices |
| `https://subscription.adjust.io` | UrlStrategy → subscriptionUrlChoices |
| `https://survey.qualtrics.com` | w → a |
| `https://tile.openstreetmap.org/` | TileSourceFactory → <clinit> |
| `https://tile.openstreetmap.org/{z` | — |
| `https://tile.opentopomap.org/{z` | — |
| `https://tiles.openseamap.org/seamark/` | TileSourceFactory → <clinit> |
| `https://tiles.wmflabs.org/hikebike/` | TileSourceFactory → <clinit> |
| `https://twitter.com` | — |
| `https://unpkg.com/leaflet@1.9.3/dist/leaflet.css` | — |
| `https://unpkg.com/leaflet@1.9.3/dist/leaflet.js` | — |
| `https://unpkg.com/leaflet@1.9.4/dist/leaflet.css` | — |
| `https://unpkg.com/leaflet@1.9.4/dist/leaflet.js` | — |
| `https://web-native-display-campaign.clevertap.com/production/lib-overlay/overlay.js` | — |
| `https://web-native-display-campaign.clevertap.com/production/lib-overlay/style.css` | — |
| `https://wizrocket.atlassian.net/wiki/spaces/TAMKB/pages/1824325665/Implementing+Web+Push+in+Shopify+if+not+using+the+Shopify+App+approach` | — |
| `https://wms.chartbundle.com/tms/v1.0/enrh/` | TileSourceFactory → <clinit> |
| `https://wms.chartbundle.com/tms/v1.0/enrl/` | TileSourceFactory → <clinit> |
| `https://wms.chartbundle.com/tms/v1.0/wac/` | TileSourceFactory → <clinit> |
| `https://www` | GpsAraTriggersManager → enable; PACustomAudienceClient → enable |
| `https://www.example.com` | BrowserActionsIntent → getBrowserActionsIntentHandlers; BrowserActionsIntent → launchIntent |
| `https://www.facebook.com` | IdentityProviders → getIdentityProviderForAccount |
| `https://www.flickr.com/photos/` | FlickrPOIProvider → getThem |
| `https://www.google.com/maps/search/?api=1&query=` | — |
| `https://www.googleadservices.com/pagead/conversion/app/deeplink?id_type=adid&sdk_version=%s&rdid=%s&bundleid=%s&retry=%s` | zzpp → zzaw |
| `https://www.googleapis.com/auth/appstate` | — |
| `https://www.googleapis.com/auth/datastoremobile` | — |
| `https://www.googleapis.com/auth/drive` | — |
| `https://www.googleapis.com/auth/drive.appdata` | — |
| `https://www.googleapis.com/auth/drive.apps` | — |
| `https://www.googleapis.com/auth/drive.file` | — |
| `https://www.googleapis.com/auth/games` | GoogleSignInOptions → <clinit> |
| `https://www.googleapis.com/auth/games.firstparty` | — |
| `https://www.googleapis.com/auth/games_lite` | GoogleSignInOptions → <clinit> |
| `https://www.googleapis.com/auth/plus.login` | — |
| `https://www.googleapis.com/auth/plus.me` | — |
| `https://www.googleapis.com/auth/userinfo.email` | — |
| `https://www.googleapis.com/auth/userinfo.profile` | — |
| `https://www.linkedin.com` | — |
| `https://www.openstreetmap.org/copyright` | — |
| `https://www.paypal.com` | — |
| `https://www.tensorflow.org/lite/guide/ops_custom` | — |
| `https://www.tensorflow.org/lite/guide/ops_select` | — |
| `https://www.vdocipher.com/api/playback/report` | e → b |
| `https://www.w3.org/Style/CSS/Test/Fonts/Ahem/` | — |
| `https://x` | FrameworkMediaDrm → addLaUrlAttributeIfMissing; FrameworkMediaDrm → adjustLicenseServerUrl |
| `https://youtrack.jetbrains.com/issue/KT-55980` | PropertyReference → getReflected |
| `https://youtrack.jetbrains.com/issue/KT-67202` | — |
| `https://{s` | — |

## 3. URI schemes / deep links (from AndroidManifest)

| Deep link | Target component |
|---|---|
| `https://apis.ooredoo.dz/pathPrefix=/PasswordResetScreen` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `http://apis.ooredoo.dz/pathPrefix=/PasswordResetScreen` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `https://myooredoo-ppd.ooredoo.dz/pathPrefix=/PasswordResetScreen` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `http://myooredoo-ppd.ooredoo.dz/pathPrefix=/PasswordResetScreen` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `https://algeria.page.link` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `ooredoodzapp://ooredoo.dz` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `http://myooredoo.dz` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `com.algeria.selfcare.app.android://applink` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `com.algeria.selfcare.app.android://` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `https://my-ooredoo.go.link` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `http://my-ooredoo.go.link` | `com.example.ooredoo_selfcare_algeria.MainActivity` |
| `fbconnect://cct.com.algeria.selfcare.app.android` | `com.facebook.CustomTabActivity` |

## 4. ContentProvider authorities

- `com.algeria.selfcare.app.android.AGCInitializeProvider`
- `com.algeria.selfcare.app.android.FacebookInitProvider`
- `com.algeria.selfcare.app.android.adjust-lifecycle-provider`
- `com.algeria.selfcare.app.android.androidx-startup`
- `com.algeria.selfcare.app.android.clevertap.fileprovider`
- `com.algeria.selfcare.app.android.firebaseinitprovider`
- `com.algeria.selfcare.app.android.flutter.image_provider`
- `com.algeria.selfcare.app.android.flutter.share_provider`
- `com.algeria.selfcare.app.android.flutterfirebasemessaginginitprovider`
- `com.algeria.selfcare.app.android.mlkitinitprovider`
- `com.facebook.katana.provider.PlatformProvider`

## 5. Third-party / SDK endpoints (grouped by service)

### adjust

- `adjust.com`
- `adjust.world`
- `app.adjust.com`
- `gdpr.adjust.com`
- `ssrv.adjust.com`
- `subscription.adjust.com`

### amazon-aws

- `d1z78r8i505acl.cloudfront.net`

### clevertap

- `clevertap-prod.com`

### facebook

- `developers.facebook.com`
- `facebook.com`
- `fbcdn.net`
- `www.facebook.com`

### firebase

- `atype.googleapis.com`
- `crashlytics.advertising.id`
- `crashlytics.installation.id`
- `dtype.googleapis.com`
- `firebase-settings.crashlytics.com`
- `firebaseinstallations.googleapis.com`
- `firebaseremoteconfig.googleapis.com`
- `firebaseremoteconfigrealtime.googleapis.com`
- `htype.googleapis.com`
- `maps.googleapis.com`
- `type.googleapis.com`
- `visionkit-pa.googleapis.com`
- `www.googleapis.com`

### google-play

- `app-measurement.com`
- `www.googleadservices.com`

### huawei

- `com.huawei.hwid.tv`
- `ro.huawei.build.display.id`

### instagram

- `instagram.com`

### linkedin

- `www.linkedin.com`

### maps

- `aerial.maps.cit.api.here.com`
- `api.openstreetmap.fr`
- `nominatim.openstreetmap.org`
- `openstreetmap.org`
- `routing.openstreetmap.de`
- `tile.openstreetmap.org`

### payments

- `www.paypal.com`

### telegram

- `com.google.cast.media`

### twitter/x

- `api.mapbox.com`
- `api.tiles.mapbox.com`
- `twitter.com`

## 6. Manifest meta-data & embedded config (client-side keys)

- `CLEVERTAP_IDENTIFIER = Identity,Phone`
- `CLEVERTAP_INAPP_EXCLUDE = SplashActivity`
- `CLEVERTAP_NOTIFICATION_ICON = ic_launcher`
- `CLEVERTAP_REGION = eu1`
- `androidx.emoji2.text.EmojiCompatInitializer = androidx.startup`
- `androidx.lifecycle.ProcessLifecycleInitializer = androidx.startup`
- `androidx.profileinstaller.ProfileInstallerInitializer = androidx.startup`
- `androidx.work.WorkManagerInitializer = androidx.startup`
- `availableLoaded = yes`
- `backend:com.google.android.datatransport.cct.CctBackendFactory = cct`
- `com.android.stamp.source = https://play.google.com/store`
- `com.android.stamp.type = STAMP_TYPE_DISTRIBUTION_APK`
- `com.android.vending.derived.apk.id = 3`
- `com.android.vending.splits.required = true`
- `com.facebook.sdk.CodelessDebugLogEnabled = true`
- `com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME = com.vdocipher.aegis.cast.internal.VdoCastOptionsProvider`
- `com.google.android.gms.cloudmessaging.FINISHED_AFTER_HANDLED = true`
- `com.google.firebase.components:com.google.firebase.FirebaseCommonKtxRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.abt.component.AbtRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.analytics.connector.internal.AnalyticsConnectorRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.crashlytics.CrashlyticsRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.crashlytics.FirebaseCrashlyticsKtxRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.datatransport.TransportRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.installations.FirebaseInstallationsKtxRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.installations.FirebaseInstallationsRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.messaging.FirebaseMessagingKtxRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.messaging.FirebaseMessagingRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.perf.FirebasePerfKtxRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.perf.FirebasePerfRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.remoteconfig.FirebaseRemoteConfigKtxRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.remoteconfig.RemoteConfigRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.firebase.sessions.FirebaseSessionsRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.mlkit.common.internal.CommonComponentRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.mlkit.vision.common.internal.VisionCommonRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:com.google.mlkit.vision.text.internal.TextRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:io.flutter.plugins.firebase.analytics.FlutterFirebaseAppRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:io.flutter.plugins.firebase.core.FlutterFirebaseCoreRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:io.flutter.plugins.firebase.crashlytics.FlutterFirebaseAppRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.google.firebase.components:io.flutter.plugins.firebase.messaging.FlutterFirebaseAppRegistrar = com.google.firebase.components.ComponentRegistrar`
- `com.huawei.hms.client.service.name:base = base:6.4.0.302`
- `com.huawei.hms.client.service.name:safetydetect = safetydetect:6.4.0.301`
- `com.huawei.hms.min_api_level:base:hmscore = 1`
- `com.huawei.hms.min_api_level:safetydetect:safetydetect = 1`
- `flutterEmbedding = 2`
- `flutter_deeplinking_enabled = true`
- `hwc-theme = androidhwext:style/Theme.Emui.Translucent`
- `io.flutter.embedded_views_preview = true`

## 7. Transport security posture

- `usesCleartextTraffic`: true
- `networkSecurityConfig`: @7F16000A

---
*Generated by static analysis only; all strings above are embedded in the APK itself and are client-visible by definition.*