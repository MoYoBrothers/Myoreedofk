package org.osmdroid.tileprovider.tilesource;
public class ThunderforestTileSource extends org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase {
    public static final int CYCLE = 0;
    public static final int LANDSCAPE = 2;
    public static final int MOBILE_ATLAS = 7;
    public static final int NEIGHBOURHOOD = 8;
    public static final int OUTDOORS = 3;
    public static final int PIONEER = 6;
    public static final int SPINAL_MAP = 5;
    private static final String THUNDERFOREST_MAPID = "THUNDERFOREST_MAPID";
    public static final int TRANSPORT = 1;
    public static final int TRANSPORT_DARK = 4;
    private static final String[] baseUrl;
    private static final String[] uiMap;
    private static final String[] urlMap;
    private final int mMap;
    private final String mMapId;
}
