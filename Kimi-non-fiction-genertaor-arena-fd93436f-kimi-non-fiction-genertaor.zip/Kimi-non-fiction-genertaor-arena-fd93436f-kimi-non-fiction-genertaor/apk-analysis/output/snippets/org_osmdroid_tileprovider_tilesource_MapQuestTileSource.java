package org.osmdroid.tileprovider.tilesource;
public class MapQuestTileSource extends org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase {
    private static final String ACCESS_TOKEN = "MAPQUEST_ACCESS_TOKEN";
    private static final String MAPBOX_MAPID = "MAPQUEST_MAPID";
    private static final String[] mapBoxBaseUrl;
    private String accessToken;
    private String mapBoxMapId;
}
