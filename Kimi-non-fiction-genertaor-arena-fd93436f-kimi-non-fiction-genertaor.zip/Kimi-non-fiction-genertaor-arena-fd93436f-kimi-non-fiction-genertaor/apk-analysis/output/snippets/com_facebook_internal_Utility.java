package com.facebook.internal;
public final class Utility {
    private static final String ARC_DEVICE_PATTERN = ".+_cheets|cheets_.+";
    public static final int DEFAULT_STREAM_BUFFER_SIZE = 8192;
    private static final String EXTRA_APP_EVENTS_INFO_FORMAT_VERSION = "a2";
    private static final String FACEBOOK_PROFILE_FIELDS = "id,name,first_name,middle_name,last_name";
    private static final String HASH_ALGORITHM_MD5 = "MD5";
    private static final String HASH_ALGORITHM_SHA1 = "SHA-1";
    private static final String HASH_ALGORITHM_SHA256 = "SHA-256";
    private static final String INSTAGRAM_PROFILE_FIELDS = "id,name,profile_picture";
    public static final com.facebook.internal.Utility INSTANCE = None;
    public static final String LOG_TAG = "FacebookSDK";
    private static final String NO_CARRIER = "NoCarrier";
    private static final int REFRESH_TIME_FOR_EXTENDED_DEVICE_INFO_MILLIS = 1800000;
    private static final String URL_SCHEME = "https";
    private static final String UTF8 = "UTF-8";
    private static volatile long availableExternalStorageGB;
    private static volatile String carrierName;
    private static volatile String deviceTimeZoneName;
    private static volatile String deviceTimezoneAbbreviation;
    private static volatile java.util.Locale locale;
    private static volatile int numCPUCores;
    private static volatile long timestampOfLastCheck;
    private static volatile long totalExternalStorageGB;
    private static volatile String versionName;
}
