#!/usr/bin/env python3
"""
build_bundle.py — Assemble the complete findings package (endpoint inventory +
feature deep-dives) into ONE standalone downloadable Markdown file.

Usage: python3 tools/build_bundle.py <output_dir>
"""

import json
import os
import re
import sys
from collections import defaultdict

OUT_NAME = "Ooredoo-1.5.17-findings-bundle.md"


def group_paths(paths):
    """Group /api/ooredoo-bff/... paths by their feature segment."""
    groups = defaultdict(list)
    other = []
    for p in paths:
        v = p["value"]
        m = re.match(r"^/api/ooredoo-bff/([a-z0-9_\-]+)/", v, re.I)
        if m:
            groups[m.group(1)].append(v)
        elif re.match(r"^/api/ooredoo-bff/[a-z0-9_\-]+$", v, re.I):
            groups["(root resources)"].append(v)
        else:
            other.append(v)
    return groups, sorted(other)


def main(out_dir):
    ep = json.load(open(os.path.join(out_dir, "endpoints.json")))
    app = ep["app"]
    man = ep["manifest"]
    fnd = ep["findings"]

    def clean_md(s):
        return "".join(c if c.isprintable() else " " for c in str(s)).strip()

    for f in fnd:
        f["value"] = clean_md(f["value"])
    for i, (l, t) in enumerate(man.get("deep_links", [])):
        man["deep_links"][i] = (clean_md(l), clean_md(t))
    man["provider_authorities"] = [clean_md(a) for a in man.get("provider_authorities", [])]
    man["meta_data"] = [clean_md(m) for m in man.get("meta_data", [])]

    hosts = [f for f in fnd if f["kind"] == "host"]
    urls = [f for f in fnd if f["kind"] == "url"]
    paths = [f for f in fnd if f["kind"] == "api-path"]
    deeplinks = man.get("deep_links", [])
    authorities = man.get("provider_authorities", [])
    metas = man.get("meta_data", [])

    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "br", os.path.join(os.path.dirname(__file__), "build_report.py"))
    # reuse classify_service without importing main
    KNOWN_SERVICES = {
        "firebase": ["firebaseio", "googleapis", "firebase", "crashlytics", "app-measurement",
                     "firebasestorage", "appspot.com"],
        "google-play/gms": ["play.google", "android.clients.google", "gtm.googleapis",
                            "googleadservices", "doubleclick", "gstatic", "type.googleapis",
                            "android.com"],
        "google-maps/geo": ["maps.google", "maps.googleapis", "geonames", "openstreetmap",
                            "tile.opentopomap", "thunderforest", "cloudmade", "mapbox",
                            "nationalmap", "openptmap", "opentopomap"],
        "adjust": ["adjust."],
        "facebook": ["facebook", "fbcdn", "fbconnect"],
        "huawei": ["huawei", "hicloud", "彩虹", "cpki-caweb"],
        "clevertap": ["clevertap"],
        "paypal": ["paypal"],
        "media/DRM": ["dashif", "vdocipher", "widevine"],
        "misc-web": ["apache.org", "w3.org", "unicode.org", "example.com", "verisign",
                     "securetrust", "ibm.com", "iandevlin", "purl.org", "opengis",
                     "picasaweb", "schemas.google", "javax.xml", "localhost"],
        "other-maps-legacy": ["flickr", "cloudmade"],
    }

    def classify(h):
        for svc, needles in KNOWN_SERVICES.items():
            for n in needles:
                if n.lower() in h.lower():
                    return svc
        return None

    first_party, third = [], defaultdict(list)
    for h in hosts:
        svc = classify(h["value"])
        (third[svc] if svc else first_party).append(h)

    bff = [p for p in paths if "ooredoo-bff" in p["value"]]
    nonbff = [p for p in paths if "ooredoo-bff" not in p["value"]]
    keycloak = [p for p in nonbff if "realms/myooredoo" in p["value"]]
    other_paths = [p for p in nonbff if "realms/myooredoo" not in p["value"]]

    groups, other_bff = group_paths(bff)

    L = []
    A = L.append

    A("# My Ooredoo Algeria — Complete Reverse-Engineering Findings Bundle")
    A("")
    A("| | |")
    A("|---|---|")
    A("| **App** | %s (`%s`) |" % (app.get("name") or "My Ooredoo", app["package"]))
    A("| **Version** | %s (versionCode %s) |" % (app.get("version"), app.get("versionCode")))
    A("| **Framework** | Flutter (Dart AOT in `lib/arm64-v8a/libapp.so`, 22.7 MB) |")
    A("| **Source bundle** | `My Ooredoo_1.5.17.apks` (base + arm64 split, merged for analysis) |")
    A("| **Method** | 100% static analysis: AndroidManifest binary-XML, 8× DEX string tables + "
      "const-string bytecode xref, resources.arsc, assets, native `.so` printable-run scan "
      "(Dart snapshot), androguard decompiler for Java-layer classes |")
    A("| **Counts** | %d URLs · %d hosts · %d API paths · %d deep links · %d provider "
      "authorities · %d manifest meta-data |" % (
          len(urls), len(hosts), len(paths), len(deeplinks), len(authorities), len(metas)))
    A("")
    A("> Static analysis of client-visible strings only — everything below ships inside "
      "the APK. Educational assignment work; no live systems were contacted.")
    A("")

    A("---")
    A("")
    A("## 1 · Deep-dive: \"Power of Snake\" gamification (the bonus/prize feature)")
    A("")
    A("> **Full standalone write-up: [`feature-power-of-snake.md`](feature-power-of-snake.md)** "
      "— API reference with reconstructed request/response JSON, module file map, state "
      "machine, gating keys, evidence appendix. Summary below.")
    A("")
    A("The French FAQ describes: buy a My Ooredoo bundle → a *Power of Snake* is added → "
      "unlock it within **7 days** → surprise gift of **2 GB up to 1 TB** free internet → "
      "bonus valid **3 days**. The Dart AOT snapshot contains the complete feature module "
      "(`features/power_snake/`), including its API layer, models, state machine and "
      "analytics. Reconstruction below; ✔ = literal string in the binary, ◐ = "
      "high-confidence inference from generated-code symbols.")
    A("")

    A("### 1.1 Backend endpoints involved")
    A("")
    A("| Endpoint | Role | Evidence |")
    A("|---|---|---|")
    A("| `GET /api/ooredoo-bff/gamification/power-snake?status=AVAILABLE` | **List my unlocked-but-unrevealed snakes** — response body is `{ total, snakes[] }` | ✔ literal path; ✔ `PowerSnakeModel(total: `, `, snakes: ` |")
    A("| `POST /api/ooredoo-bff/gamification/power-snake/{uuid}` ◐ | **Unlock / reveal the prize** (\"prize delivery\") — returns `{ message, ... }`, app state becomes `powerSnakeUnlockSuccess(message:)` and the `reveal_gift.json` animation plays | ✔ base path literal ends with `/` (Dio path-template join with the item's `uuid`); ✔ `UnlockPowerSnakeUseCase`, `unlockPowerSnake`, `PowerSnakeRedeemResponse(message: ` — exact `{uuid}` suffix shape not a literal string |")
    A("| `POST /api/ooredoo-bff/bundle/bundlePurchase/v2` (also `cvm/bundlePurchase`, `bundle/boost/bundle-purchase`, `yooz/purchase`, …) | **The \"sent package\" purchase calls** — the *response* carries field `powerSnakeReward` which flags that a snake was granted by the purchase | ✔ purchase path literals; ✔ `, powerSnakeReward: ` model field; ✔ `isPowerSnakeEligibleFromResponse`, `checkPowerSnakeEnabledForBundle` |")
    A("| `GET /api/ooredoo-bff/gamification/status` · `…/gamification/history` · `POST …/gamification/play` | Gamification framework status / prize history / play tracking | ✔ literal paths |")
    A("| `POST /api/ooredoo-bff/flarie/player/token` | Separate Flarie web-game token (companion gamification) | ✔ literal path |")
    A("")

    A("### 1.2 Data models (json_serializable/freezed — fields recovered from `toString` fragments & FromJson symbols)")
    A("")
    A("```")
    A("PowerSnakeModel            { total: int,  snakes: List<PowerSnakeItemModel> }")
    A("PowerSnakeItemModel        { uuid, status(AVAILABLE/REDEEMED/EXPIRED), expiryDate,")
    A("                              reward / assignedReward, redeemedDate, bundleName }")
    A("PowerSnakeRedeemResponse   { message, … }        // unlock/redeem result")
    A("FaqItemModel               { … }                 // the \"Comment ça marche ?\" FAQ")
    A("BundlePurchaseResponse(v2) { …, powerSnakeReward, hasEPayment, … }")
    A("```")
    A("")
    A("*Exact JSON key casing can't be fully proven from a string pool; field names above "
      "are the Dart symbol names which json_serializable keeps aligned with the keys.*")
    A("")

    A("### 1.3 End-to-end flow")
    A("")
    A("```")
    A(" 1. BUY      app ──POST /api/ooredoo-bff/bundle/bundlePurchase/v2──► BFF")
    A("             (Authorization: Bearer <Keycloak OIDC token>, X-Device-Fingerprint)")
    A("             ◄── response { …, powerSnakeReward: true, … }      [server grants snake]")
    A("             UI: PowerSnakePurchaseSuccessCard \"un Power of Snake sera ajouté\"")
    A("")
    A(" 2. LIST     app ──GET /api/ooredoo-bff/gamification/power-snake?status=AVAILABLE──►")
    A("             ◄── { total, snakes: [ { uuid, status, expiryDate, … } ] }")
    A("             UI: /PowerSnakeScreen → PowerSnakeCard list (7-day expiry shown)")
    A("")
    A(" 3. UNLOCK   user taps \"unlock_power_snake\" → showUnlockPowerSnakeBottomSheet")
    A("             app ──POST /api/ooredoo-bff/gamification/power-snake/{uuid}──►")
    A("             ◄── PowerSnakeRedeemResponse { message }")
    A("             UI: powerSnakeUnlockSuccess → reveal_gift.json animation →")
    A("                 GiftScreen shows the surprise (2 GB … 1 TB, valid 3 days)")
    A("")
    A(" 4. TRACK    gamification/status · gamification/history · analytics events:")
    A("             onPowerSnakeAccessed / onPowerSnakeActivation /")
    A("             onPowerSnakeAttribution / onPowerSnakePopupViewed")
    A("```")
    A("")

    A("### 1.4 Feature gating & ancillary strings (all literal)")
    A("")
    A("- Remote-config / experiment keys: `myo_puzzle_snake_enabled`, "
      "`is_puzzle_snake_auto_popup_enabled`, `myo_power_snake_auto_popup_restricted_time_in_hours`, "
      "`myo_puzzle_snake_auto_popup_restricted_time_in_hours`, `myo_power_snake_popup_image`, "
      "`myo_puzzle_snake_title`, `myo_puzzle_snake_url`, `excluded_rate_for_puzzle_snake`, "
      "`myo_is_disabled_employee_check_for_puzzle_snake`, `gamification-UI-Enable`")
    A("- Logic helpers: `checkPowerSnakeTimeRestriction`, `checkPuzzleSnakeTimeRestriction`, "
      "`getPowerSnakePopupLastShown` / `markPowerSnakeShown` (popup cadence), "
      "`handlePuzzleSnakeDeeplink` (deep-link entry)")
    A("- i18n keys: `unlock_power_snake`, `unlock_my_power_snake`, "
      "`unlock_power_snake_description`, `unlock_power_snake_description2`, "
      "`unlock_power_snake_success_title`, `unlock_power_snake_success_description`, "
      "`power_snake_unlock_warning_message`")
    A("- Screens/routes: `/PowerSnakeScreen`, `/PuzzleSnakeWebView`, `/YoozPuzzleSnakeWebView` "
      "(the Yooz sub-brand variant), `PowerSnakeEpaymentBottomSheet` (paid bundles via ePay "
      "also grant snakes), `assets/lotties/reveal_gift.json`")
    A("- Note: **no third-party prize URL exists** — the snake prize is granted and revealed "
      "entirely through the `ooredoo-bff` endpoints above.")
    A("")

    A("### 1.5 Deep-dive: \"Spin & Win\" (daily wheel — *\"tente ta chance et gagne jusqu'à 30 Go\"*)")
    A("")
    A("Native fortune-wheel game rendered by the bundled `flutter_fortune_wheel` package "
      "(+ a Yooz fork `yz_flutter_fortune_wheel`). Same gamification framework as Power of "
      "Snake, sharing its endpoints. Evidence tags as before.")
    A("")
    A("**APIs called (all literal paths):**")
    A("")
    A("| Endpoint | Role in Spin & Win | Evidence |")
    A("|---|---|---|")
    A("| `GET /api/ooredoo-bff/gamification/status` | **Eligibility & attempts check before the wheel** — returns remaining daily attempts, enablement flag and the reset time that drives the countdown | ✔ path; ✔ `getGameStatus` / `checkGameStatus`; ✔ `\"Checking Attempts\"`, `\"No Attempts Left\"`, bare `attempts` field |")
    A("| `POST /api/ooredoo-bff/gamification/play` | **The spin itself** — one call per attempt; the *response* (`PlayResponse`) carries the server-chosen prize and starts the next-play countdown; app emits `onGamePlaySuccess`/`onGamePlayFail`, maps to `wheelSpinGiftWon` / `wheelspinGiftWonFailed`, marks `wheelSpinUsed` (`WHEEL_USED`) | ✔ path; ✔ `PlayResponse`, `playGame`, `\"Starting countdown for next play\"` |")
    A("| `GET /api/ooredoo-bff/gamification/history` | Prizes-won feed (`prizesWon`) | ✔ path; ✔ `initGamificationHistoryTab` |")
    A("| `POST /api/ooredoo-bff/flarie/player/token` | Sibling web-game (Flarie) token; has its own attempt pool (`flarieAttempts`, `showFlarieNoAttempts`) | ✔ |")
    A("")
    A("**Frontend vs backend split:**")
    A("")
    A("- **Wheel animation = pure frontend.** `flutter_fortune_wheel` renders the slices; "
      "`package:flutter_fortune_wheel/src/core/random.dart` drives the visual spin. "
      "*The outcome is not decided by the animation* — the app first receives the result "
      "from `POST /gamification/play` and the wheel animates to the server-chosen slice "
      "(server-authoritative wheel; `playSpinGameCallback`).")
    A("- **Daily attempt limit = enforced server-side**, rendered client-side. The dialog "
      "you saw is `showSpinLimitDialog` with i18n keys `spin_limit_reached_title` / "
      "`spin_limit_reached_desc` / `spin_limit_reached_btn` — shown when `gamification/status` "
      "reports no attempts left. The `\"Temps restant: 14:38:30\"` countdown is formatted "
      "locally (`spin_time_till_reset`) but ticks toward a **server-provided reset timestamp** "
      "(`\"Starting countdown for next play\"` after each play). Manipulating the clock or UI "
      "wouldn't grant another spin — the play call would still be rejected.")
    A("- **Visibility/eligibility = remote config.** `myo_spin`, `myo_spin_title`, "
      "`myo_spin_description`, `myo_spin_floating`, `myo_spin_services` toggles (Firebase "
      "Remote Config/CleverTap), `updateSpinAndWindEligibility`, deep-link entry via "
      "`handleSpinGameDeeplink` (route assets `spin_new_icon.png`, `wheel_arrow.png`).")
    A("- Prize value (\"jusqu'à 30 Go\") comes from the game configuration delivered by the "
      "backend/status — segments are not hardcoded in the binary.")
    A("")

    A("---")
    A("")
    A("## 2 · First-party backend surface")
    A("")
    A("### 2.1 First-party hosts")
    A("")
    A("| Host | Notes |")
    A("|---|---|")
    fp_notes = {
        "apis.ooredoo.dz": "main BFF / REST gateway (also app-link host for password reset)",
        "api.ooredoo.dz": "legacy API — `http://api.ooredoo.dz/Shops/getWilayas` runs **cleartext HTTP**",
        "ooredoo.dz": "custom scheme host (`ooredoodzapp://ooredoo.dz`)",
        "myooredoo-ppd.ooredoo.dz": "PPD environment app-link (password reset)",
        "myooredoo.dz": "http app-link host",
        "my-ooredoo-new-app.appspot.com": "Firebase project bucket",
        "my-ooredoo-new-app.firebasestorage.app": "Firebase Storage",
        "algeria.page.link": "Firebase Dynamic Links (referral/MGM)",
        "my-ooredoo.go.link": "Adjust attribution link",
    }
    for h in first_party:
        A("| `%s` | %s |" % (h["value"], fp_notes.get(h["value"], "")))
    A("")

    A("### 2.2 BFF API paths (`/api/ooredoo-bff/…`) grouped by feature — %d total" % len(bff))
    A("")
    for g in sorted(groups):
        A("**`%s/`** (%d)" % (g, len(groups[g])))
        A("")
        for v in groups[g]:
            A("- `%s`" % v)
        A("")
    if other_bff:
        A("**root-level**")
        A("")
        for v in other_bff:
            A("- `%s`" % v)
        A("")

    A("### 2.3 Authentication (Keycloak OIDC)")
    A("")
    for p in keycloak:
        A("- `%s`" % p["value"])
    A("")
    A("Realm: **`myooredoo`** — standard OpenID-Connect token/userinfo/logout endpoints. "
      "The app stores and sends `Authorization: Bearer …` on BFF calls and additionally "
      "sends an `X-Device-Fingerprint` header (both literal in the snapshot).")
    A("")

    A("### 2.4 Other API paths (legacy / third-party called directly)")
    A("")
    for p in other_paths:
        A("- `%s`" % p["value"])
    A("")

    A("---")
    A("")
    A("## 3 · Absolute URLs (%d)" % len(urls))
    A("")
    A("| URL | Referenced by |")
    A("|---|---|")
    for u in urls:
        refs = "; ".join(r.split("->")[0].strip("L").rstrip(";").split("/")[-1] +
                         " → " + r.split("->")[-1] if "->" in r else r
                         for r in u["refs"][:2])
        A("| `%s` | %s |" % (u["value"][:150], refs or ""))
    A("")

    A("## 4 · All hosts (%d) incl. third-party SDKs" % len(hosts))
    A("")
    A("### 4.1 Third-party endpoints grouped by service")
    A("")
    for svc in sorted(third):
        A("**%s**" % svc)
        A("")
        A(", ".join("`%s`" % h["value"] for h in third[svc]))
        A("")
    A("### 4.2 Unclassified hosts (manual triage)")
    A("")
    A(", ".join("`%s`" % h["value"] for h in first_party))
    A("")

    A("## 5 · Deep links / URI schemes (%d)" % len(deeplinks))
    A("")
    A("| Deep link | Target |")
    A("|---|---|")
    for link, tgt in deeplinks:
        A("| `%s` | `%s` |" % (link, tgt or ""))
    A("")

    A("## 6 · ContentProvider authorities (%d)" % len(authorities))
    A("")
    for au in authorities:
        A("- `%s`" % au)
    A("")

    A("## 7 · Manifest meta-data (client-side config & keys) (%d)" % len(metas))
    A("")
    for m in metas:
        A("- `%s`" % m)
    A("")

    A("## 8 · Transport-security posture")
    A("")
    A("- `usesCleartextTraffic`: %s · `networkSecurityConfig`: %s"
      % (man.get("usesCleartextTraffic"), man.get("networkSecurityConfig")))
    A("- Cleartext `http://` usage observed: `api.ooredoo.dz/Shops/getWilayas`, "
      "`apis.ooredoo.dz` (bare-http literal + http app-links), plus legacy map/geo SDKs")
    A("- Native protections observed: `libsigner.so`, `libtoolChecker.so`, `librjsniffer-lib.so`, "
      "root/emulator/Xposed checks (`com.xamdesign.safe_device.*`, `root_checker_plus`, "
      "`com.emrys.rjsniffer.*`), Play-Integrity helpers (`com.android.sec.utils.Play`), "
      "Dart-side SSL pinning (public patch scene confirms)")
    A("")

    A("## 9 · Embedded SDK/stack map")
    A("")
    A("Flutter 2-embedding · Keycloak OIDC · Firebase (Crashlytics, Messaging, Perf, "
      "RemoteConfig, Analytics, Installations, Sessions, MLKit OCR) · CleverTap (region `eu1`) · "
      "Adjust (`my-ooredoo.go.link`) · Facebook SDK · VdoCipher (DRM/cast) · Huawei HMS "
      "SafetyDetect 6.4.0 · Qualtrics surveys · Google Sign-In · UCrop · barcode scanner · "
      "inappwebview · media3/ExoPlayer · lottie · sqflite · webviewflutter")
    A("")

    A("## 10 · Method & artifact index")
    A("")
    A("- `endpoints.json` / `endpoints.csv` — full machine-readable inventory with "
      "class→method references")
    A("- `snippets/` — 30 decompiled Java classes (Java-layer xref top hits)")
    A("- `seeds/ooredoo-intel.md` — pre-analysis intel & validation checklist (all items hit)")
    A("- `tools/` — `extract_endpoints.py` (harvester), `build_report.py`, `build_bundle.py`")
    A("- Sample-run validation: `a2dp.Vol` APK correctly inventoried before the real target")
    A("")
    A("*Bundle generated from static analysis of `My Ooredoo_1.5.17.apks` "
      "(base.apk SHA-256 of merged analysis image: "
      "`2fc1a516a91fb5e5564af03d13a30807802dc6d25abc129406a90b5610cf64bd`).*")

    out = os.path.join(out_dir, OUT_NAME)
    with open(out, "w") as f:
        f.write("\n".join(L))
    print("[+] wrote %s (%d lines, %d bytes)" % (out, len(L), os.path.getsize(out)))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)
    main(sys.argv[1])
