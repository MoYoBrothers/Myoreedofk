#!/usr/bin/env python3
"""
build_report.py — Turns endpoints.json (from extract_endpoints.py) into a
human-readable Markdown report, grouped and classified, with references back
into the code. Optionally dumps decompiled Java snippets of the classes that
reference the most network identifiers.

Usage: python3 build_report.py <app.apk> <output_dir>
"""

import json
import os
import re
import sys
from collections import defaultdict
from urllib.parse import urlparse

# Hosts -> well-known services, so the report can group third-party endpoints
KNOWN_SERVICES = {
    "firebase": ["firebaseio.com", "googleapis.com", "firebaseinstallations",
                 "crashlytics", "fcm.googleapis", "firebase-settings"],
    "google-play": ["play.googleapis", "android.clients.google", "app-measurement",
                    "gtm.googleapis", "googleadservices", "doubleclick"],
    "sentry": ["sentry.io", "sentry"],
    "crashlytics": ["crashlytics"],
    "onesignal": ["onesignal"],
    "appsflyer": ["appsflyer"],
    "adjust": ["adjust.com", "adjust.world"],
    "branch": ["branch.io", "app.link"],
    "facebook": ["facebook.com", "fbcdn", "graph.facebook"],
    "huawei": ["huawei", "hicloud", "agconnect"],
    "amplitude": ["amplitude"],
    "mixpanel": ["mixpanel"],
    "segment": ["segment.io", "segment.com"],
    "instabug": ["instabug", "instabugs"],
    "intercom": ["intercom"],
    "zendesk": ["zendesk", "zopim"],
    "veriff": ["veriff"],
    "recaptcha": ["recaptcha", "gstatic"],
    "adobe": ["adobe", "demdex", "omtrdc"],
    "youtube": ["youtube", "ytimg"],
    "twitter/x": ["twitter.com", "x.com", "twimg"],
    "instagram": ["instagram"],
    "linkedin": ["linkedin"],
    "telegram": ["telegram", "t.me"],
    "criteo": ["criteo"],
    "smartlook": ["smartlook"],
    "raygun": ["raygun"],
    "bugsnag": ["bugsnag"],
    "datadog": ["datadoghq", "datadog"],
    "newrelic": ["newrelic", "nr-data"],
    "appdynamics": ["appdynamics"],
    "dynatrace": ["dynatrace"],
    "optimizely": ["optimizely", "cdn.optimizely"],
    "clevertap": ["clevertap"],
    "moengage": ["moengage"],
    "braze": ["braze", "appboy"],
    "airship": ["airship", "urbanairship"],
    "pushwoosh": ["pushwoosh"],
    "accesstrade": ["accesstrade"],
    "cloudflare": ["cloudflare", "cloudflarestorage"],
    "amazon-aws": ["amazonaws.com", "awsapps", "elasticbeanstalk", "cloudfront"],
    "azure": ["azurewebsites", "azure-api", "azureedge", "blob.core.windows", "onmicrosoft"],
    "maps": ["maps.googleapis", "mapbox", "here.com", "tomtom", "openstreetmap"],
    "payments": ["stripe", "paypal", "checkout.com", "adyen", "payzone", "cib.gov",
                 "satim", "baridimob", "gpages", "charges"],
    "recaptcha-enterprise": ["recaptchaenterprise"],
    "appdome": ["appdome"],
    "promon": ["promon", "shield"],
    "verimatrix": ["verimatrix"],
    "arneca": ["arneca"],
}


def classify_service(host):
    h = host.lower()
    for svc, needles in KNOWN_SERVICES.items():
        for n in needles:
            if n in h:
                return svc
    return None


def company_hosts(pkg_hint):
    return []


def short_class(cname):
    """'La2dp/Vol/Service;' -> 'a2dp/Vol/Service'"""
    c = cname.strip()
    if c.startswith("L"):
        c = c[1:]
    return c.rstrip(";")


def render_refs(refs, n=3):
    out = []
    for r in refs[:n]:
        if "->" in r:
            c, meth = r.split("->", 1)
            out.append("%s → %s" % (short_class(c).split("/")[-1], meth))
        else:
            out.append(r)
    return "; ".join(out)


def clean_md(s):
    """Make a string safe for markdown tables / text output."""
    return "".join(c if c.isprintable() and c not in "`" else " "
                   for c in str(s)).strip()


def main(apk_path, out_dir):
    with open(os.path.join(out_dir, "endpoints.json")) as f:
        data = json.load(f)

    app = data["app"]
    manifest = data["manifest"]
    findings = data["findings"]
    for f in findings:
        f["value"] = clean_md(f["value"])
    for i, (l, t) in enumerate(manifest.get("deep_links", [])):
        manifest["deep_links"][i] = (clean_md(l), clean_md(t))
    manifest["provider_authorities"] = [clean_md(a) for a in manifest.get("provider_authorities", [])]
    manifest["meta_data"] = [clean_md(m) for m in manifest.get("meta_data", [])]

    hosts = [f for f in findings if f["kind"] == "host"]
    urls = [f for f in findings if f["kind"] == "url"]
    api_paths = [f for f in findings if f["kind"] == "api-path"]
    rel_paths = [f for f in findings if f["kind"] == "relative-path"]
    deeplinks = [f for f in findings if f["kind"] == "deeplink"]
    authorities = [f for f in findings if f["kind"] == "provider-authority"]
    secrets = [f for f in findings if f["kind"].startswith("secret-style")]

    # ---- host classification
    own_hosts, third = [], defaultdict(list)
    for h in hosts:
        v = h["value"]
        svc = classify_service(v)
        # package-based ownership heuristic
        brand = app["package"].split(".")[-2] if len(app["package"].split(".")) > 2 else app["package"]
        if svc:
            third[svc].append(h)
        else:
            own_hosts.append(h)

    lines = []
    A = lines.append
    A("# API / Endpoint Inventory Report — static analysis")
    A("")
    A("| | |")
    A("|---|---|")
    A("| App | **%s** (`%s`) |" % (app.get("name") or "n/a", app["package"]))
    A("| Version | %s (code %s) |" % (app.get("version"), app.get("versionCode")))
    A("| APK | `%s` |" % app.get("apk"))
    A("| Method | Static analysis (androguard DEX/ARSC/AXML parsing + full "
      "string-table harvest + cross-reference to code) |")
    A("")
    A("**Legend:** *url* = absolute URL found in code/resources · *host* = bare "
      "hostname · *api-path* = endpoint path (Retrofit-style relative or "
      "path-looking constant) · *deeplink* = manifest URI scheme · "
      "*authority* = ContentProvider authority")
    A("")

    # ---- 1. own / first-party API surface
    A("## 1. First-party hosts & API surface")
    A("")
    A("Hosts that do **not** belong to a known third-party SDK — i.e. the app's "
      "own backend surface:")
    A("")
    A("| Host | Sources | Referenced by (code) |")
    A("|---|---|---|")
    for h in own_hosts:
        A("| `%s` | %s | %s |" % (h["value"], ", ".join(h["sources"]),
                                  render_refs(h["refs"]) or "—"))
    A("")

    A("### API endpoint paths (relative paths / route constants)")
    A("")
    A("| Path | Referenced by (class → method) |")
    A("|---|---|")
    for p in api_paths:
        A("| `%s` | %s |" % (p["value"], render_refs(p["refs"], n=2) or "—"))
    A("")

    A("### Other relative paths that look like routes (needs manual triage)")
    A("")
    A("```")
    for p in rel_paths[:250]:
        A(p["value"])
    A("```")
    A("")

    # ---- 2. absolute URLs
    A("## 2. Absolute URLs found")
    A("")
    A("| URL | Kind evidence (referencing class → method) |")
    A("|---|---|")
    for u in urls:
        A("| `%s` | %s |" % (u["value"][:160], render_refs(u["refs"]) or "—"))
    A("")

    # ---- 3. deep links
    A("## 3. URI schemes / deep links (from AndroidManifest)")
    A("")
    A("| Deep link | Target component |")
    A("|---|---|")
    for link, target in manifest.get("deep_links", []):
        A("| `%s` | `%s` |" % (link, target or "—"))
    A("")

    # ---- 4. providers
    A("## 4. ContentProvider authorities")
    A("")
    for au in sorted(manifest.get("provider_authorities", [])):
        A("- `%s`" % au)
    A("")

    # ---- 5. third-party
    A("## 5. Third-party / SDK endpoints (grouped by service)")
    A("")
    for svc in sorted(third):
        A("### %s" % svc)
        A("")
        for h in third[svc]:
            A("- `%s`" % h["value"])
        A("")

    # ---- 6. meta-data / config keys
    A("## 6. Manifest meta-data & embedded config (client-side keys)")
    A("")
    for m in manifest.get("meta_data", []):
        A("- `%s`" % m)
    A("")
    if secrets:
        A("### Key/token-shaped strings in the code")
        A("")
        for s in secrets:
            A("- `%s` *(%s)*" % (s["value"][:120], s["kind"].split(":", 1)[-1]))
        A("")

    A("## 7. Transport security posture")
    A("")
    A("- `usesCleartextTraffic`: %s" % manifest.get("usesCleartextTraffic"))
    A("- `networkSecurityConfig`: %s" % manifest.get("networkSecurityConfig"))
    A("")

    A("---")
    A("*Generated by static analysis only; all strings above are embedded in the "
      "APK itself and are client-visible by definition.*")

    report = "\n".join(lines)
    with open(os.path.join(out_dir, "report.md"), "w") as f:
        f.write(report)
    print("[+] Wrote %s (%d lines)" % (os.path.join(out_dir, "report.md"), len(lines)))

    # ---- snippets: decompile classes that reference the most endpoints
    try:
        import zipfile as _zip
        from androguard.core.dex import DEX as _DEX
        from androguard.decompiler.decompile import DvClass as _DvClass
        try:
            from loguru import logger as _lg
            _lg.remove()
        except Exception:
            pass
        snip_dir = os.path.join(out_dir, "snippets")
        os.makedirs(snip_dir, exist_ok=True)

        class_score = defaultdict(int)
        for f in findings:
            for r in f["refs"]:
                cname = r.split("->", 1)[0]
                class_score[cname] += 1
        top = [c for c, _ in sorted(class_score.items(), key=lambda kv: -kv[1])[:30]]
        want = set(top)
        print("[*] Decompiling %d referencing classes ..." % len(top))
        with _zip.ZipFile(apk_path) as z:
            for dn in sorted(n for n in z.namelist()
                             if re.match(r"^classes\d*\.dex$", n)):
                if not want:
                    break
                try:
                    d = _DEX(z.read(dn))
                except Exception:
                    continue
                try:
                    classes = d.get_classes()
                except Exception:
                    continue
                for cls in classes:
                    cn = cls.get_name()
                    if cn in want:
                        try:
                            src = _DvClass(cls, d).get_source()
                            fn = cn[1:-1].replace("/", "_").replace("$", "_")[:150] + ".java"
                            with open(os.path.join(snip_dir, fn), "w") as fh:
                                fh.write(src)
                        except Exception as e:
                            print("  [!] decompile %s failed: %s" % (cn, e), file=sys.stderr)
                        want.discard(cn)
                del d
    except Exception as e:
        print("  [!] snippet pass failed: %s" % e, file=sys.stderr)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
