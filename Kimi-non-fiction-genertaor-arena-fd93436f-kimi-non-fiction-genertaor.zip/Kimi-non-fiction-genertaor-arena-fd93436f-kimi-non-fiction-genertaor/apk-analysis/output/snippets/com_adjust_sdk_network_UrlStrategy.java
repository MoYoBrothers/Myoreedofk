package com.adjust.sdk.network;
public class UrlStrategy {
    private static final String BASE_URL_IO = "https://app.adjust.io";
    private static final String GDPR_URL_IO = "https://gdpr.adjust.io";
    private static final String PURCHASE_VERIFICATION_URL_IO = "https://ssrv.adjust.io";
    private static final String SUBSCRIPTION_URL_IO = "https://subscription.adjust.io";
    final java.util.List baseUrlChoicesList;
    private final String baseUrlOverwrite;
    int choiceIndex;
    final java.util.List gdprUrlChoicesList;
    private final String gdprUrlOverwrite;
    final java.util.List purchaseVerificationUrlChoicesList;
    private final String purchaseVerificationUrlOverwrite;
    int startingChoiceIndex;
    final java.util.List subscriptionUrlChoicesList;
    private final String subscriptionUrlOverwrite;
    private final java.util.List urlStrategyDomains;
    private final boolean useSubdomains;
    boolean wasLastAttemptSuccess;
    boolean wasLastAttemptWithOverwrittenUrl;
}
