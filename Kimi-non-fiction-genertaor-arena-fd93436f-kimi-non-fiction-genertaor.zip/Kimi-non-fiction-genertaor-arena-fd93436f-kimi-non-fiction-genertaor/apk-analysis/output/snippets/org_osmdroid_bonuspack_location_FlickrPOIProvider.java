package org.osmdroid.bonuspack.location;
public class FlickrPOIProvider {
    protected String mApiKey;
}
