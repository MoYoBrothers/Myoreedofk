package com.fasterxml.jackson.databind.ext;
public class DOMSerializer extends com.fasterxml.jackson.databind.ser.std.StdSerializer {
    protected final javax.xml.transform.TransformerFactory transformerFactory;
}
