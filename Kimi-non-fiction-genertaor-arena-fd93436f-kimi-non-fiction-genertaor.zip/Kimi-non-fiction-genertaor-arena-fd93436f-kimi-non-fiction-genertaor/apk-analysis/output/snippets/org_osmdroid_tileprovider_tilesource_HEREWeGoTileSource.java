package org.osmdroid.tileprovider.tilesource;
public class HEREWeGoTileSource extends org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase {
    private static final String APPCODE = "HEREWEGO_APPCODE";
    private static final String COPYRIGHT = "\xa9 1987 - 2019 HERE. All rights reserved.";
    private static final String HEREWEGO_APPID = "HEREWEGO_APPID";
    private static final String HEREWEGO_DOMAIN_OVERRIDE = "HEREWEGO_OVERRIDE";
    private static final String HEREWEGO_MAPID = "HEREWEGO_MAPID";
    private static final String[] mapBoxBaseUrl;
    private String appCode;
    private String appId;
    private String domainOverride;
    private String herewegoMapId;
}
