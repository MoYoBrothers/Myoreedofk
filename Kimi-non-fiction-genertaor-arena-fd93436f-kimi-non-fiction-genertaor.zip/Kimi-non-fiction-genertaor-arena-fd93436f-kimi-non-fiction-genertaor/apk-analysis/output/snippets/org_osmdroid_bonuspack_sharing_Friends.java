package org.osmdroid.bonuspack.sharing;
public class Friends {
    public static final String NAV_SERVER_URL = "https://comob.org/sharing/";
    public java.util.ArrayList friendsList;
    protected String mUserAgent;
    public java.util.ArrayList partners;
}
