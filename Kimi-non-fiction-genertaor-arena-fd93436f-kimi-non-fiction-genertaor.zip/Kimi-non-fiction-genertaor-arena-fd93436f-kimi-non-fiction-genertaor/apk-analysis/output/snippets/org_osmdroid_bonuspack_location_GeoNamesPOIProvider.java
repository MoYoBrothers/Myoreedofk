package org.osmdroid.bonuspack.location;
public class GeoNamesPOIProvider {
    protected String mUserName;
}
