package org.osmdroid.bonuspack.kml;
public class KmlDocument implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
    protected static java.util.HashMap KEYWORDS_DICTIONARY;
    public org.osmdroid.bonuspack.kml.KmlFolder mKmlRoot;
    protected java.io.File mLocalFile;
    protected int mMaxStyleId;
    protected java.util.HashMap mStyles;
}
