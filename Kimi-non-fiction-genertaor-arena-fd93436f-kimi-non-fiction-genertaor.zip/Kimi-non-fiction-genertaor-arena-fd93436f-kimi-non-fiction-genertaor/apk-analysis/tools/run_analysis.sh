#!/usr/bin/env bash
# Full static-analysis pipeline: APK -> endpoint inventory + report
set -euo pipefail
APK="${1:?usage: run_analysis.sh <app.apk> [output_dir]}"
OUT="${2:-output}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
echo "==> Stage 1/2: exhaustive harvest"
python3 "$ROOT/tools/extract_endpoints.py" "$APK" "$ROOT/$OUT"
echo "==> Stage 2/2: report build"
python3 "$ROOT/tools/build_report.py" "$APK" "$ROOT/$OUT"
echo "==> Done. See $ROOT/$OUT/report.md"
