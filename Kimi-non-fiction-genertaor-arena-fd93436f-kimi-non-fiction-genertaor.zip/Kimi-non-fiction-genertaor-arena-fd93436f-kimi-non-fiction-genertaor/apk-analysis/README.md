# APK Endpoint Harvester — static URI/URL/API inventory

Course assignment tooling: decompile an Android APK and produce an exhaustive,
evidence-linked inventory of **every URI / URL / API endpoint** embedded in it.

Legitimate educational use: static analysis of client-visible strings only.
Everything harvested here ships inside the APK and is by definition visible to
anyone who unzips it. No dynamic testing, no traffic interception, no auth
bypass — pure string/manifest forensics.

## Toolchain (all installable from PyPI — no external downloads needed)

| Tool | Role |
|---|---|
| **androguard** 4.x | DEX/binary-XML/ARSC parsing, DEX decompiler (DAD), cross-references |
| **pyaxmlparser** | auxiliary manifest parsing |
| **apkInspector** | APK/ZIP structure inspection |
| **jdk4py** | bundled JDK (for any Java-side tooling) |

> Note: jadx/ghidra CLI binaries can't be fetched in a network-restricted
> environment (their release CDNs are blocked). androguard's built-in DAD
> decompiler covers the "read the underlying code" need; if you run this
> outside, drop jadx into `JADX_HOME` and the same pipeline can be extended.

## Usage

```bash
pip3 install --break-system-packages androguard pyaxmlparser apkInspector jdk4py jpype1
python3 tools/extract_endpoints.py <app.apk> output    # stage 1: harvest
python3 tools/build_report.py       <app.apk> output   # stage 2: report + snippets
# or: bash tools/run_analysis.sh <app.apk> output
```

## What stage 1 (extract_endpoints.py) harvests

1. **AndroidManifest.xml** — package identity, deep links (`scheme://host/path`
   per activity), ContentProvider authorities, `meta-data` (API keys, SDK IDs),
   `usesCleartextTraffic` / `networkSecurityConfig`.
2. **classes*.dex** — every string constant via the DEX string table:
   - absolute URLs (`https?://…`, `ws(s)://`, `ftp://`) — including URLs buried
     mid-string in HTML/JSON;
   - bare hostnames (TLD-validated, file-extension false-positives filtered);
   - API path candidates (`/api/v2/...`-style, Retrofit route-shaped strings);
   - credential-shaped strings (`AIza…`, `sk_live_…`, JWTs, AWS keys…).
   Every hit is cross-referenced to the **class → method** that references it.
3. **resources.arsc** — all string resources, all locales.
4. **assets/, res/raw/, bundled text files** — JSON configs, Flutter assets,
   google-services.json, .env files, HTML/JS bundles.
5. **lib/**/*.so** — byte-level `strings`-style scan of native libraries.

## Outputs (stage 2: build_report.py)

- `report.md` — human-readable inventory, grouped:
  1. first-party hosts + API paths (with referencing code)
  2. absolute URLs (with referencing code)
  3. deep links / URI schemes
  4. provider authorities
  5. third-party SDK endpoints grouped by service (Firebase, Sentry, AppsFlyer…)
  6. manifest meta-data & client-side keys
  7. transport-security posture
- `endpoints.json` / `endpoints.csv` — machine-readable full inventory with
  sources and code references.
- `snippets/` — decompiled Java (androguard/DAD) of the top classes that
  reference network identifiers.
- `summary.json` — counts.

## Validation

Pipeline validated end-to-end against a real third-party APK
(`a2dp.Vol` 2.12.9.2); see `output/` for the sample run — e.g. it correctly
attributed `http://maps.google.com/maps?q=` to `StoreLoc → grabGPS/clearLoc`
and produced decompiled snippets of those classes.
